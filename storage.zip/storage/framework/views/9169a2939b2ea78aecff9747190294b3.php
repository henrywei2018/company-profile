
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
    'description' => null,
    'keywords' => null,
    'image' => null,
    'type' => 'website',
    'breadcrumbs' => null,
    'bodyClass' => '',
    'showHeader' => true,
    'showFooter' => true,
    'noindex' => false
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
    'description' => null,
    'keywords' => null,
    'image' => null,
    'type' => 'website',
    'breadcrumbs' => null,
    'bodyClass' => '',
    'showHeader' => true,
    'showFooter' => true,
    'noindex' => false
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?> 

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title><?php echo e($title ?? ($autoSeo['title'] ?? $siteConfig['site_title'])); ?></title>
    <meta name="description" content="<?php echo e($description ?? ($autoSeo['description'] ?? $siteConfig['site_description'])); ?>">
    <meta name="keywords" content="<?php echo e($keywords ?? ($autoSeo['keywords'] ?? $siteConfig['site_keywords'])); ?>">
    <meta name="author" content="<?php echo e($companyProfile->company_name ?? config('app.name')); ?>">
    
    
    <?php if($noindex): ?>
    <meta name="robots" content="noindex, nofollow">
    <?php else: ?>
    <meta name="robots" content="index, follow">
    <?php endif; ?>

    
    <meta property="og:title" content="<?php echo e($title ?? ($autoSeo['title'] ?? $siteConfig['site_title'])); ?>">
    <meta property="og:description" content="<?php echo e($description ?? ($autoSeo['description'] ?? $siteConfig['site_description'])); ?>">
    <meta property="og:image" content="<?php echo e($image ?? ($autoSeo['image'] ?? asset($siteConfig['site_logo']))); ?>">
    <meta property="og:url" content="<?php echo e($autoSeo['url'] ?? request()->url()); ?>">
    <meta property="og:type" content="<?php echo e($type ?? ($autoSeo['type'] ?? 'website')); ?>">
    <meta property="og:site_name" content="<?php echo e($companyProfile->company_name ?? config('app.name')); ?>">

    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($title ?? ($autoSeo['title'] ?? $siteConfig['site_title'])); ?>">
    <meta name="twitter:description" content="<?php echo e($description ?? ($autoSeo['description'] ?? $siteConfig['site_description'])); ?>">
    <meta name="twitter:image" content="<?php echo e($image ?? ($autoSeo['image'] ?? asset($siteConfig['site_logo']))); ?>">

    
    <link rel="canonical" href="<?php echo e($autoSeo['url'] ?? request()->url()); ?>">

    
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset($siteConfig['site_favicon'] ?? 'favicon.ico')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset($siteConfig['site_logo'] ?? 'images/logo.png')); ?>">

    
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Inter:400,500,600,700,800,900&display=swap" rel="stylesheet" />

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/orange-theme.css'); ?>
    
    
    <?php echo $__env->yieldPushContent('styles'); ?>

    
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-VYHSLQXJE5"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-VYHSLQXJE5');
    </script>

    <?php if($siteConfig['facebook_pixel'] ?? false): ?>
        <!-- Facebook Pixel -->
        <script>
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '<?php echo e($siteConfig['facebook_pixel']); ?>');
            fbq('track', 'PageView');
        </script>
        <noscript>
            <img height="1" width="1" style="display:none" 
                 src="https://www.facebook.com/tr?id=<?php echo e($siteConfig['facebook_pixel']); ?>&ev=PageView&noscript=1"/>
        </noscript>
    <?php endif; ?>

    
    <script>
        window.App = {
            name: '<?php echo e(config("app.name")); ?>',
            url: '<?php echo e(config("app.url")); ?>',
            locale: '<?php echo e(app()->getLocale()); ?>',
            csrf_token: '<?php echo e(csrf_token()); ?>',
            company: {
                name: '<?php echo e($companyProfile->company_name ?? config("app.name")); ?>',
                phone: '<?php echo e($contactInfo["phone"] ?? ""); ?>',
                email: '<?php echo e($contactInfo["email"] ?? ""); ?>',
                whatsapp: '<?php echo e($socialMedia["whatsapp"] ?? ""); ?>'
            },
            routes: {
                home: '<?php echo e(route("home")); ?>',
                contact: '<?php echo e(route("contact.index")); ?>',
                services: '<?php echo e(route("services.index")); ?>',
                portfolio: '<?php echo e(route("portfolio.index")); ?>',
                quotation: '<?php echo e(route("quotation.create")); ?>'
            }
        };
    </script>
    
</head>

<body class="bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 <?php echo e($bodyClass); ?>">
    
    <?php if($announcementBanner && $announcementBanner['message']): ?>
        <div id="announcement-banner" class="bg-blue-600 text-white py-2 px-4 text-center text-sm">
            <div class="max-w-7xl mx-auto flex items-center justify-between">
                <div class="flex-1 text-center">
                    <?php echo $announcementBanner['message']; ?>

                </div>
                <?php if($announcementBanner['dismissible'] ?? true): ?>
                <button onclick="closeAnnouncement()" class="ml-4 text-white hover:text-gray-200 transition-colors duration-300">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if($showHeader): ?>
        <?php if (isset($component)) { $__componentOriginalb146cbf8306c95b172d2591af732a390 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb146cbf8306c95b172d2591af732a390 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb146cbf8306c95b172d2591af732a390)): ?>
<?php $attributes = $__attributesOriginalb146cbf8306c95b172d2591af732a390; ?>
<?php unset($__attributesOriginalb146cbf8306c95b172d2591af732a390); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb146cbf8306c95b172d2591af732a390)): ?>
<?php $component = $__componentOriginalb146cbf8306c95b172d2591af732a390; ?>
<?php unset($__componentOriginalb146cbf8306c95b172d2591af732a390); ?>
<?php endif; ?>
    <?php endif; ?>

    
    <?php if($breadcrumbs && count($breadcrumbs) > 1): ?>
        <?php if (isset($component)) { $__componentOriginal01c1b0e46c89eaeff9b0aabe5d063e2a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal01c1b0e46c89eaeff9b0aabe5d063e2a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public.breadcrumb','data' => ['items' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal01c1b0e46c89eaeff9b0aabe5d063e2a)): ?>
<?php $attributes = $__attributesOriginal01c1b0e46c89eaeff9b0aabe5d063e2a; ?>
<?php unset($__attributesOriginal01c1b0e46c89eaeff9b0aabe5d063e2a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01c1b0e46c89eaeff9b0aabe5d063e2a)): ?>
<?php $component = $__componentOriginal01c1b0e46c89eaeff9b0aabe5d063e2a; ?>
<?php unset($__componentOriginal01c1b0e46c89eaeff9b0aabe5d063e2a); ?>
<?php endif; ?>
    <?php endif; ?>

    
    <main class="min-h-screen">
        <?php echo e($slot); ?>

    </main>

    
    <?php if($showFooter): ?>
        <?php if (isset($component)) { $__componentOriginalbb84be681bbe94cc31d6257779433433 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb84be681bbe94cc31d6257779433433 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb84be681bbe94cc31d6257779433433)): ?>
<?php $attributes = $__attributesOriginalbb84be681bbe94cc31d6257779433433; ?>
<?php unset($__attributesOriginalbb84be681bbe94cc31d6257779433433); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb84be681bbe94cc31d6257779433433)): ?>
<?php $component = $__componentOriginalbb84be681bbe94cc31d6257779433433; ?>
<?php unset($__componentOriginalbb84be681bbe94cc31d6257779433433); ?>
<?php endif; ?>
    <?php endif; ?>

    
    <?php if($socialMedia['whatsapp'] ?? $contactInfo['whatsapp'] ?? false): ?>
        <?php if (isset($component)) { $__componentOriginal625aeb68e970de6b44f724c6c1686dd6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal625aeb68e970de6b44f724c6c1686dd6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public.whatsapp-button','data' => ['number' => $socialMedia['whatsapp'] ?? $contactInfo['whatsapp'],'message' => 'Hello! I would like to inquire about services from ' . ($companyProfile->company_name ?? config('app.name')) . '.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.whatsapp-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($socialMedia['whatsapp'] ?? $contactInfo['whatsapp']),'message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Hello! I would like to inquire about services from ' . ($companyProfile->company_name ?? config('app.name')) . '.')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal625aeb68e970de6b44f724c6c1686dd6)): ?>
<?php $attributes = $__attributesOriginal625aeb68e970de6b44f724c6c1686dd6; ?>
<?php unset($__attributesOriginal625aeb68e970de6b44f724c6c1686dd6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal625aeb68e970de6b44f724c6c1686dd6)): ?>
<?php $component = $__componentOriginal625aeb68e970de6b44f724c6c1686dd6; ?>
<?php unset($__componentOriginal625aeb68e970de6b44f724c6c1686dd6); ?>
<?php endif; ?>
    <?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginal950bbb07df3854f26f404fef4e16c01f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal950bbb07df3854f26f404fef4e16c01f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public.scroll-to-top','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public.scroll-to-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal950bbb07df3854f26f404fef4e16c01f)): ?>
<?php $attributes = $__attributesOriginal950bbb07df3854f26f404fef4e16c01f; ?>
<?php unset($__attributesOriginal950bbb07df3854f26f404fef4e16c01f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal950bbb07df3854f26f404fef4e16c01f)): ?>
<?php $component = $__componentOriginal950bbb07df3854f26f404fef4e16c01f; ?>
<?php unset($__componentOriginal950bbb07df3854f26f404fef4e16c01f); ?>
<?php endif; ?>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Close announcement banner
            window.closeAnnouncement = function() {
                const banner = document.getElementById('announcement-banner');
                if (banner) {
                    banner.style.display = 'none';
                    localStorage.setItem('announcement_closed_<?php echo e(date("Y-m-d")); ?>', 'true');
                }
            };

            // Check if announcement was closed today
            const announcementKey = 'announcement_closed_<?php echo e(date("Y-m-d")); ?>';
            if (localStorage.getItem(announcementKey)) {
                const banner = document.getElementById('announcement-banner');
                if (banner) banner.style.display = 'none';
            }

            // Smooth scroll for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });


            // Add loading class removal for images
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                if (img.complete) {
                    img.classList.add('loaded');
                } else {
                    img.addEventListener('load', function() {
                        this.classList.add('loaded');
                    });
                }
            });

            // Add error handling for missing images
            images.forEach(img => {
                img.addEventListener('error', function() {
                    this.style.display = 'none';
                });
            });

            // Performance optimization: Preload critical resources
            if ('requestIdleCallback' in window) {
                requestIdleCallback(() => {
                    // Preload important routes
                    const criticalRoutes = [
                        '<?php echo e(route("services.index")); ?>',
                        '<?php echo e(route("portfolio.index")); ?>',
                        '<?php echo e(route("contact.index")); ?>'
                    ];
                    
                    criticalRoutes.forEach(url => {
                        const link = document.createElement('link');
                        link.rel = 'prefetch';
                        link.href = url;
                        document.head.appendChild(link);
                    });
                });
            }

            // Add intersection observer for animations
            if ('IntersectionObserver' in window) {
                const animationObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            entry.target.classList.add('animate-in');
                            animationObserver.unobserve(entry.target);
                        }
                    });
                }, { threshold: 0.1 });

                // Observe elements with animation classes
                document.querySelectorAll('[class*="animate-"]').forEach(el => {
                    animationObserver.observe(el);
                });
            }

            // Add scroll direction detection
            let lastScrollY = window.scrollY;
            window.addEventListener('scroll', () => {
                const currentScrollY = window.scrollY;
                const direction = currentScrollY > lastScrollY ? 'down' : 'up';
                
                document.body.setAttribute('data-scroll-direction', direction);
                lastScrollY = currentScrollY;
            }, { passive: true });

            // Add click outside handler utility
            window.clickOutside = function(element, callback) {
                document.addEventListener('click', function(event) {
                    if (!element.contains(event.target)) {
                        callback();
                    }
                });
            };

            // Add debounce utility function
            window.debounce = function(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            };
        });

        // Handle online/offline status
        window.addEventListener('online', () => {
            document.body.classList.remove('offline');
            console.log('✅ Back online');
        });

        window.addEventListener('offline', () => {
            document.body.classList.add('offline');
            console.log('📵 You are offline');
        });

        // Add resize handler for responsive adjustments
        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                window.dispatchEvent(new CustomEvent('debouncedResize'));
            }, 150);
        });
    </script>

    
    <style>
        /* Loading states */
        img {
            transition: opacity 0.3s ease;
        }
        
        img:not(.loaded) {
            opacity: 0.7;
        }
        
        img.loaded {
            opacity: 1;
        }

        /* Offline indicator */
        body.offline::before {
            content: '📵 You are currently offline';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: #ef4444;
            color: white;
            text-align: center;
            padding: 0.5rem;
            font-size: 0.875rem;
            z-index: 9999;
        }

        /* Scroll direction classes */
        body[data-scroll-direction="down"] .scroll-hide {
            transform: translateY(-100%);
        }
        
        body[data-scroll-direction="up"] .scroll-show {
            transform: translateY(0);
        }

        /* Print styles */
        @media print {
            .no-print {
                display: none !important;
            }
            
            body {
                background: white !important;
                color: black !important;
            }
        }

        /* High contrast mode support */
        @media (prefers-contrast: high) {
            * {
                text-shadow: none !important;
                box-shadow: none !important;
            }
        }

        /* Reduced motion support */
        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        }
    </style>
</body>
</html><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/layouts/public.blade.php ENDPATH**/ ?>