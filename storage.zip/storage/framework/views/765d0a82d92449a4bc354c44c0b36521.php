

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'route' => '#',
    'previewRoute' => '#',
    'statisticsRoute' => '#',
    'canForceDelete' => false,
    'showPriorityActions' => true,
    'showAssignActions' => false,
    'type' => 'admin', // admin or client
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'route' => '#',
    'previewRoute' => '#',
    'statisticsRoute' => '#',
    'canForceDelete' => false,
    'showPriorityActions' => true,
    'showAssignActions' => false,
    'type' => 'admin', // admin or client
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!-- Bulk Actions Toolbar -->
<div id="bulk-actions-toolbar" class="hidden bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-4">
    <div class="flex items-center justify-between">
        <div class="flex items-center space-x-4">
            <span class="text-sm font-medium text-blue-700 dark:text-blue-300">
                <span id="selected-count">0</span> message(s) selected
            </span>
            
            <!-- Quick Actions -->
            <div class="flex items-center space-x-2">
                <button type="button" onclick="bulkMarkAsRead()" 
                        class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded text-green-700 bg-green-100 hover:bg-green-200 dark:bg-green-900 dark:text-green-300 dark:hover:bg-green-800">
                    <?php if (isset($component)) { $__componentOriginal435b806fd72030048bfbb4999bd2b7da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal435b806fd72030048bfbb4999bd2b7da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.check','data' => ['class' => 'w-4 h-4 mr-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal435b806fd72030048bfbb4999bd2b7da)): ?>
<?php $attributes = $__attributesOriginal435b806fd72030048bfbb4999bd2b7da; ?>
<?php unset($__attributesOriginal435b806fd72030048bfbb4999bd2b7da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal435b806fd72030048bfbb4999bd2b7da)): ?>
<?php $component = $__componentOriginal435b806fd72030048bfbb4999bd2b7da; ?>
<?php unset($__componentOriginal435b806fd72030048bfbb4999bd2b7da); ?>
<?php endif; ?>
                    Mark as Read
                </button>
                
                <button type="button" onclick="bulkMarkAsUnread()" 
                        class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded text-yellow-700 bg-yellow-100 hover:bg-yellow-200 dark:bg-yellow-900 dark:text-yellow-300 dark:hover:bg-yellow-800">
                    <?php if (isset($component)) { $__componentOriginal20e7faa61f28c0b135bf174e432b4e0b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20e7faa61f28c0b135bf174e432b4e0b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.minus-circle','data' => ['class' => 'w-4 h-4 mr-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.minus-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20e7faa61f28c0b135bf174e432b4e0b)): ?>
<?php $attributes = $__attributesOriginal20e7faa61f28c0b135bf174e432b4e0b; ?>
<?php unset($__attributesOriginal20e7faa61f28c0b135bf174e432b4e0b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20e7faa61f28c0b135bf174e432b4e0b)): ?>
<?php $component = $__componentOriginal20e7faa61f28c0b135bf174e432b4e0b; ?>
<?php unset($__componentOriginal20e7faa61f28c0b135bf174e432b4e0b); ?>
<?php endif; ?>
                    Mark as Unread
                </button>
            </div>
        </div>
        
        <div class="flex items-center space-x-2">
            <!-- Priority Dropdown -->
            <?php if($showPriorityActions): ?>
            <?php if (isset($component)) { $__componentOriginal1cbebd4ce05f40dc7fe1efacfcd290bd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1cbebd4ce05f40dc7fe1efacfcd290bd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.bulk-actions.priority-dropdown','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.bulk-actions.priority-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1cbebd4ce05f40dc7fe1efacfcd290bd)): ?>
<?php $attributes = $__attributesOriginal1cbebd4ce05f40dc7fe1efacfcd290bd; ?>
<?php unset($__attributesOriginal1cbebd4ce05f40dc7fe1efacfcd290bd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1cbebd4ce05f40dc7fe1efacfcd290bd)): ?>
<?php $component = $__componentOriginal1cbebd4ce05f40dc7fe1efacfcd290bd; ?>
<?php unset($__componentOriginal1cbebd4ce05f40dc7fe1efacfcd290bd); ?>
<?php endif; ?>
            <?php endif; ?>
            
            <!-- More Actions Dropdown -->
            <?php if (isset($component)) { $__componentOriginalc238e377c3a41f127112535073315faf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc238e377c3a41f127112535073315faf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.bulk-actions.more-actions','data' => ['canForceDelete' => $canForceDelete,'showAssignActions' => $showAssignActions]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.bulk-actions.more-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['canForceDelete' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($canForceDelete),'showAssignActions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($showAssignActions)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc238e377c3a41f127112535073315faf)): ?>
<?php $attributes = $__attributesOriginalc238e377c3a41f127112535073315faf; ?>
<?php unset($__attributesOriginalc238e377c3a41f127112535073315faf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc238e377c3a41f127112535073315faf)): ?>
<?php $component = $__componentOriginalc238e377c3a41f127112535073315faf; ?>
<?php unset($__componentOriginalc238e377c3a41f127112535073315faf); ?>
<?php endif; ?>
            
            <!-- Clear Selection -->
            <button type="button" onclick="clearSelection()" 
                    class="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
                Clear Selection
            </button>
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<?php if (isset($component)) { $__componentOriginalf6879c58bdab7f8997d2d04e4ea38260 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf6879c58bdab7f8997d2d04e4ea38260 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.bulk-actions.confirmation-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.bulk-actions.confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf6879c58bdab7f8997d2d04e4ea38260)): ?>
<?php $attributes = $__attributesOriginalf6879c58bdab7f8997d2d04e4ea38260; ?>
<?php unset($__attributesOriginalf6879c58bdab7f8997d2d04e4ea38260); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6879c58bdab7f8997d2d04e4ea38260)): ?>
<?php $component = $__componentOriginalf6879c58bdab7f8997d2d04e4ea38260; ?>
<?php unset($__componentOriginalf6879c58bdab7f8997d2d04e4ea38260); ?>
<?php endif; ?>

<!-- JavaScript -->
<script>
// Global variables for bulk actions
let selectedMessages = new Set();
let currentBulkAction = null;
let currentBulkData = {};

// Configuration
const bulkActionConfig = {
    route: '<?php echo e($route); ?>',
    previewRoute: '<?php echo e($previewRoute); ?>',
    statisticsRoute: '<?php echo e($statisticsRoute); ?>',
    canForceDelete: <?php echo e($canForceDelete ? 'true' : 'false'); ?>,
    type: '<?php echo e($type); ?>'
};

// Initialize bulk actions
document.addEventListener('DOMContentLoaded', function() {
    initializeBulkActions();
});

function initializeBulkActions() {
    // Add event listeners to checkboxes
    const checkboxes = document.querySelectorAll('input[name="message_ids[]"]');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', handleCheckboxChange);
    });
    
    // Add master checkbox listener
    const masterCheckbox = document.getElementById('select-all');
    if (masterCheckbox) {
        masterCheckbox.addEventListener('change', handleMasterCheckboxChange);
    }
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('#priority-dropdown-btn')) {
            document.getElementById('priority-dropdown')?.classList.add('hidden');
        }
        if (!event.target.closest('#more-actions-btn')) {
            document.getElementById('more-actions-dropdown')?.classList.add('hidden');
        }
    });
}

function handleCheckboxChange(event) {
    const messageId = parseInt(event.target.value);
    
    if (event.target.checked) {
        selectedMessages.add(messageId);
    } else {
        selectedMessages.delete(messageId);
    }
    
    updateBulkActionsToolbar();
    updateMasterCheckbox();
}

function handleMasterCheckboxChange(event) {
    const checkboxes = document.querySelectorAll('input[name="message_ids[]"]');
    
    checkboxes.forEach(checkbox => {
        const messageId = parseInt(checkbox.value);
        
        if (event.target.checked) {
            checkbox.checked = true;
            selectedMessages.add(messageId);
        } else {
            checkbox.checked = false;
            selectedMessages.delete(messageId);
        }
    });
    
    updateBulkActionsToolbar();
}

function updateBulkActionsToolbar() {
    const toolbar = document.getElementById('bulk-actions-toolbar');
    const countElement = document.getElementById('selected-count');
    
    if (selectedMessages.size > 0) {
        toolbar.classList.remove('hidden');
        countElement.textContent = selectedMessages.size;
    } else {
        toolbar.classList.add('hidden');
    }
}

function updateMasterCheckbox() {
    const masterCheckbox = document.getElementById('select-all');
    const checkboxes = document.querySelectorAll('input[name="message_ids[]"]');
    
    if (!masterCheckbox) return;
    
    const checkedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
    
    if (checkedCount === 0) {
        masterCheckbox.checked = false;
        masterCheckbox.indeterminate = false;
    } else if (checkedCount === checkboxes.length) {
        masterCheckbox.checked = true;
        masterCheckbox.indeterminate = false;
    } else {
        masterCheckbox.checked = false;
        masterCheckbox.indeterminate = true;
    }
}

function clearSelection() {
    selectedMessages.clear();
    
    // Uncheck all checkboxes
    const checkboxes = document.querySelectorAll('input[name="message_ids[]"], #select-all');
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
        checkbox.indeterminate = false;
    });
    
    updateBulkActionsToolbar();
}

// Bulk action functions
async function bulkMarkAsRead() {
    await bulkAction('mark_read');
}

async function bulkMarkAsUnread() {
    await bulkAction('mark_unread');
}

async function bulkArchive() {
    await bulkAction('archive');
}

async function bulkDelete() {
    showConfirmationModal(
        'Delete Messages',
        `Are you sure you want to delete ${selectedMessages.size} message(s)? This action cannot be undone.`,
        'delete'
    );
}

async function bulkDeleteThreads() {
    showConfirmationModal(
        'Delete Conversations',
        `Are you sure you want to delete entire conversations for ${selectedMessages.size} message(s)? This will delete all messages in these conversation threads and cannot be undone.`,
        'delete_thread'
    );
}

async function bulkSetPriority(priority) {
    // Close dropdown
    document.getElementById('priority-dropdown')?.classList.add('hidden');
    
    await bulkAction('change_priority', { priority: priority });
}

async function bulkAction(action, additionalData = {}) {
    if (selectedMessages.size === 0) {
        showNotification('Please select messages first.', 'warning');
        return;
    }
    
    try {
        const requestData = {
            action: action,
            message_ids: Array.from(selectedMessages),
            ...additionalData
        };
        
        const response = await fetch(bulkActionConfig.route, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json',
            },
            body: JSON.stringify(requestData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
            
            // Update statistics if provided
            if (data.statistics) {
                updateStatisticsDisplay(data.statistics);
            }
            
            // Clear selection and reload page
            clearSelection();
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showNotification(data.message || 'An error occurred while performing the bulk action.', 'error');
        }
    } catch (error) {
        console.error('Bulk action error:', error);
        showNotification('An error occurred while performing the bulk action.', 'error');
    }
}

function showConfirmationModal(title, message, action, additionalData = {}) {
    const modal = document.getElementById('bulk-action-modal');
    const titleEl = document.getElementById('modal-title');
    const messageEl = document.getElementById('modal-message');
    const impactPreview = document.getElementById('impact-preview');
    const confirmBtn = document.getElementById('confirm-action-btn');
    
    titleEl.textContent = title;
    messageEl.textContent = message;
    impactPreview?.classList.add('hidden');
    
    confirmBtn.textContent = 'Confirm';
    confirmBtn.className = 'px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-800';
    confirmBtn.onclick = confirmBulkAction;
    
    currentBulkAction = action;
    currentBulkData = additionalData;
    
    modal.classList.remove('hidden');
}

function closeModal() {
    document.getElementById('bulk-action-modal')?.classList.add('hidden');
    currentBulkAction = null;
    currentBulkData = {};
}

async function confirmBulkAction() {
    if (!currentBulkAction) return;
    
    closeModal();
    await bulkAction(currentBulkAction, currentBulkData);
}

function showNotification(message, type = 'info') {
    // Implementation for notifications
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 px-4 py-3 rounded-lg shadow-lg ${getNotificationClasses(type)}`;
    notification.innerHTML = `
        <div class="flex items-center">
            <span class="mr-2">${getNotificationIcon(type)}</span>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function getNotificationClasses(type) {
    switch (type) {
        case 'success': return 'bg-green-600 text-white';
        case 'error': return 'bg-red-600 text-white';
        case 'warning': return 'bg-yellow-600 text-white';
        default: return 'bg-blue-600 text-white';
    }
}

function getNotificationIcon(type) {
    switch (type) {
        case 'success': return '✅';
        case 'error': return '❌';
        case 'warning': return '⚠️';
        default: return 'ℹ️';
    }
}

function updateStatisticsDisplay(stats) {
    // Update statistics cards if they exist
    // Implementation depends on your specific statistics display
}
</script><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/bulk-actions/bulk-actions.blade.php ENDPATH**/ ?>