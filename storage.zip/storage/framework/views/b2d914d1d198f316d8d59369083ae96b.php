
<?php if (isset($component)) { $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.public','data' => ['title' => 'Our Portfolio - '.e($siteConfig['site_title']).'','description' => 'Explore our completed construction and engineering projects. See the quality and craftsmanship we deliver.','keywords' => 'construction portfolio, completed projects, construction gallery, engineering projects','type' => 'website']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.public'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Our Portfolio - '.e($siteConfig['site_title']).'','description' => 'Explore our completed construction and engineering projects. See the quality and craftsmanship we deliver.','keywords' => 'construction portfolio, completed projects, construction gallery, engineering projects','type' => 'website']); ?>


<section class="relative pt-32 pb-20 bg-gradient-to-br from-orange-50 via-white to-amber-50 overflow-hidden">
    
    <div class="absolute inset-0 bg-[url('/images/grid.svg')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]"></div>
    
    <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
        <div class="text-center mb-12">
            <h1 class="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                Our 
                <span class="bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                    Portfolio
                </span>
            </h1>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
                Discover our completed construction and engineering projects that showcase our expertise, quality, and commitment to excellence.
            </p>
        </div>

        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div class="text-center">
                <div class="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                    </svg>
                </div>
                <div class="text-3xl font-bold text-gray-900 mb-2"><?php echo e($stats['total_projects']); ?>+</div>
                <div class="text-gray-600">Completed Projects</div>
            </div>
            
            <div class="text-center">
                <div class="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
                <div class="text-3xl font-bold text-gray-900 mb-2"><?php echo e($stats['satisfied_clients']); ?>+</div>
                <div class="text-gray-600">Happy Clients</div>
            </div>
            
            <div class="text-center">
                <div class="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                    </svg>
                </div>
                <div class="text-3xl font-bold text-gray-900 mb-2"><?php echo e($stats['active_categories']); ?>+</div>
                <div class="text-gray-600">Project Categories</div>
            </div>
            
            <div class="text-center">
                <div class="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <div class="text-3xl font-bold text-gray-900 mb-2"><?php echo e($stats['years_experience']); ?>+</div>
                <div class="text-gray-600">Years Experience</div>
            </div>
        </div>

        
        <?php if($featuredProjects && $featuredProjects->count() > 0): ?>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php $__currentLoopData = $featuredProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="group relative rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
                <div class="aspect-w-16 aspect-h-10 relative">
                    <?php if($project->featured_image_url): ?>
                        <img src="<?php echo e($project->featured_image_url); ?>" 
                             alt="<?php echo e($project->title); ?>" 
                             class="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500">
                    <?php else: ?>
                        <div class="w-full h-64 bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center">
                            <svg class="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                            </svg>
                        </div>
                    <?php endif; ?>
                    <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                    <div class="absolute top-4 left-4">
                        <span class="bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                            Featured
                        </span>
                    </div>
                </div>
                <div class="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <h3 class="text-xl font-bold mb-2 group-hover:text-orange-300 transition-colors">
                        <?php echo e($project->title); ?>

                    </h3>
                    <?php if($project->category): ?>
                    <p class="text-orange-200 text-sm mb-2"><?php echo e($project->category->name); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo e(route('portfolio.show', $project->slug)); ?>" 
                       class="inline-flex items-center text-orange-300 hover:text-white transition-colors">
                        View Details
                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                        </svg>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</section>


<section class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col lg:flex-row gap-8">
            
            <div class="lg:w-1/4">
                <div class="bg-gray-50 rounded-2xl p-6 sticky top-8">
                    <h3 class="text-lg font-bold text-gray-900 mb-6">Filter Projects</h3>
                    
                    <form method="GET" id="portfolio-filters" class="space-y-6">
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                            <input type="text" 
                                   name="search" 
                                   value="<?php echo e($search); ?>"
                                   placeholder="Search projects..."
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm">
                        </div>

                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                            <select name="category" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm">
                                <option value="all" <?php echo e($category === 'all' ? 'selected' : ''); ?>>All Categories</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->slug); ?>" <?php echo e($category === $cat->slug ? 'selected' : ''); ?>>
                                    <?php echo e($cat->name); ?> (<?php echo e($cat->active_projects_count); ?>)
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Service</label>
                            <select name="service" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm">
                                <option value="all" <?php echo e($service === 'all' ? 'selected' : ''); ?>>All Services</option>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($svc->slug); ?>" <?php echo e($service === $svc->slug ? 'selected' : ''); ?>>
                                    <?php echo e($svc->title); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Year</label>
                            <select name="year" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm">
                                <option value="all" <?php echo e($year === 'all' ? 'selected' : ''); ?>>All Years</option>
                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($yr); ?>" <?php echo e($year == $yr ? 'selected' : ''); ?>>
                                    <?php echo e($yr); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
                            <select name="sort" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm">
                                <option value="latest" <?php echo e($sortBy === 'latest' ? 'selected' : ''); ?>>Latest First</option>
                                <option value="oldest" <?php echo e($sortBy === 'oldest' ? 'selected' : ''); ?>>Oldest First</option>
                                <option value="featured" <?php echo e($sortBy === 'featured' ? 'selected' : ''); ?>>Featured First</option>
                                <option value="title" <?php echo e($sortBy === 'title' ? 'selected' : ''); ?>>Title A-Z</option>
                            </select>
                        </div>

                        
                        <div class="space-y-3">
                            <button type="submit" 
                                    class="w-full bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors text-sm font-medium">
                                Apply Filters
                            </button>
                            <a href="<?php echo e(route('portfolio.index')); ?>" 
                               class="w-full block text-center border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium">
                                Clear All
                            </a>
                        </div>
                    </form>

                    
                    <div class="mt-8 pt-6 border-t border-gray-200">
                        <h4 class="text-sm font-medium text-gray-900 mb-4">Quick Stats</h4>
                        <div class="space-y-2 text-sm text-gray-600">
                            <div class="flex justify-between">
                                <span>Showing:</span>
                                <span class="font-medium"><?php echo e($projects->count()); ?> of <?php echo e($projects->total()); ?></span>
                            </div>
                            <?php if($search): ?>
                            <div class="flex justify-between">
                                <span>Search:</span>
                                <span class="font-medium">"<?php echo e($search); ?>"</span>
                            </div>
                            <?php endif; ?>
                            <?php if($category && $category !== 'all'): ?>
                            <div class="flex justify-between">
                                <span>Category:</span>
                                <span class="font-medium"><?php echo e($categories->where('slug', $category)->first()?->name); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="lg:w-3/4">
                
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
                    <div>
                        <h2 class="text-2xl font-bold text-gray-900 mb-2">
                            <?php if($search || ($category && $category !== 'all') || ($service && $service !== 'all') || ($year && $year !== 'all')): ?>
                                Filtered Projects
                            <?php else: ?>
                                All Projects
                            <?php endif; ?>
                        </h2>
                        <p class="text-gray-600">
                            Showing <?php echo e($projects->count()); ?> of <?php echo e($projects->total()); ?> projects
                        </p>
                    </div>
                </div>

                
                <?php if($projects && $projects->count() > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden transform hover:-translate-y-2">
                        
                        <div class="relative h-48 overflow-hidden">
                            <?php if($project->featured_image_url): ?>
                                <img src="<?php echo e($project->featured_image_url); ?>" 
                                     alt="<?php echo e($project->title); ?>" 
                                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                            <?php else: ?>
                                <div class="w-full h-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                                    <svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                                    </svg>
                                </div>
                            <?php endif; ?>
                            <div class="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                            
                            
                            <div class="absolute top-3 left-3 flex gap-2">
                                <?php if($project->featured): ?>
                                <span class="bg-orange-500 text-white px-2 py-1 rounded-lg text-xs font-medium">
                                    Featured
                                </span>
                                <?php endif; ?>
                                <?php if($project->category): ?>
                                <span class="bg-white/90 text-gray-800 px-2 py-1 rounded-lg text-xs font-medium">
                                    <?php echo e($project->category->name); ?>

                                </span>
                                <?php endif; ?>
                            </div>

                            <?php if($project->year): ?>
                            <div class="absolute top-3 right-3">
                                <span class="bg-black/60 text-white px-2 py-1 rounded-lg text-xs font-medium">
                                    <?php echo e($project->year); ?>

                                </span>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        
                        <div class="p-6">
                            <h3 class="text-lg font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
                                <?php echo e($project->title); ?>

                            </h3>
                            
                            <div class="flex items-center text-sm text-gray-500 mb-3">
                                <?php if($project->service): ?>
                                <span class="text-orange-600 font-medium"><?php echo e($project->service->title); ?></span>
                                <?php endif; ?>
                                <?php if($project->location): ?>
                                <span class="mx-2">•</span>
                                <span><?php echo e($project->location); ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if($project->short_description): ?>
                            <p class="text-gray-600 text-sm mb-4 line-clamp-2">
                                <?php echo e($project->short_description); ?>

                            </p>
                            <?php endif; ?>
                            
                            <div class="flex items-center justify-between">
                                <?php if($project->client): ?>
                                <span class="text-xs text-gray-500">
                                    Client: <?php echo e($project->client->name); ?>

                                </span>
                                <?php endif; ?>
                                <a href="<?php echo e(route('portfolio.show', $project->slug)); ?>" 
                                   class="inline-flex items-center text-orange-600 font-medium text-sm hover:text-orange-700 transition-colors">
                                    View Details
                                    <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <?php if($projects->hasPages()): ?>
                <div class="flex justify-center">
                    <?php echo e($projects->links()); ?>

                </div>
                <?php endif; ?>
                <?php else: ?>
                
                <div class="text-center py-12">
                    <svg class="w-24 h-24 text-gray-300 mx-auto mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                    </svg>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">No Projects Found</h3>
                    <p class="text-gray-600 mb-8">
                        We couldn't find any projects matching your criteria. Try adjusting your filters.
                    </p>
                    <a href="<?php echo e(route('portfolio.index')); ?>" 
                       class="inline-flex items-center px-6 py-3 bg-orange-600 text-white font-semibold rounded-xl hover:bg-orange-700 transition-colors">
                        View All Projects
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>


<section class="py-20 bg-gradient-to-r from-orange-600 via-amber-600 to-orange-700">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 class="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Start Your Project?
        </h2>
        <p class="text-xl text-orange-100 mb-8">
            Join our satisfied clients and let us bring your construction vision to life.
        </p>
        <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="<?php echo e(route('contact.index')); ?>" 
               class="inline-flex items-center px-8 py-4 bg-white text-orange-600 font-semibold rounded-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-lg">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-3.582 8-8 8a8.959 8.959 0 01-4.906-1.405L3 21l2.595-5.094A8.959 8.959 0 013 12c0-4.418 3.582-8 8-8s8 3.582 8 8z"/>
                </svg>
                Get Free Consultation
            </a>
            <a href="<?php echo e(route('services.index')); ?>" 
               class="inline-flex items-center px-8 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-orange-600 transition-all duration-300">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                </svg>
                View Our Services
            </a>
        </div>
    </div>
</section>


<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-submit form on filter change
    const filterForm = document.getElementById('portfolio-filters');
    const filterInputs = filterForm.querySelectorAll('select, input[name="search"]');
    
    filterInputs.forEach(input => {
        if (input.type === 'text') {
            // Debounce search input
            let timeout;
            input.addEventListener('input', function() {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    filterForm.submit();
                }, 500);
            });
        } else {
            // Auto-submit on select change
            input.addEventListener('change', function() {
                filterForm.submit();
            });
        }
    });
    
    // Loading state for form submission
    filterForm.addEventListener('submit', function() {
        const submitButton = this.querySelector('button[type="submit"]');
        const originalText = submitButton.innerHTML;
        
        submitButton.innerHTML = `
            <svg class="animate-spin -ml-1 mr-3 h-4 w-4 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Filtering...
        `;
        submitButton.disabled = true;
    });
});
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('styles'); ?>
<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.aspect-w-16 {
    position: relative;
    padding-bottom: 62.5%;
}

.aspect-w-16 > * {
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
}

/* Smooth transitions */
.transition-all {
    transition-property: all;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 300ms;
}

/* Sticky sidebar on larger screens */
@media (min-width: 1024px) {
    .sticky {
        position: sticky;
        top: 2rem;
    }
}
</style>
<?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $attributes = $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $component = $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/pages/portfolio/index.blade.php ENDPATH**/ ?>