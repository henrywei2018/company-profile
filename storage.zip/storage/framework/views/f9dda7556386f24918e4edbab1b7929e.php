

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'priorities' => [
        'low' => ['label' => 'Low Priority', 'color' => 'gray'],
        'normal' => ['label' => 'Normal Priority', 'color' => 'blue'],
        'high' => ['label' => 'High Priority', 'color' => 'yellow'],
        'urgent' => ['label' => 'Urgent Priority', 'color' => 'red']
    ]
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'priorities' => [
        'low' => ['label' => 'Low Priority', 'color' => 'gray'],
        'normal' => ['label' => 'Normal Priority', 'color' => 'blue'],
        'high' => ['label' => 'High Priority', 'color' => 'yellow'],
        'urgent' => ['label' => 'Urgent Priority', 'color' => 'red']
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="relative">
    <button type="button" id="priority-dropdown-btn" onclick="togglePriorityDropdown()"
            class="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
        <?php if (isset($component)) { $__componentOriginal9d62a86fc4a9075719386ebc7d3356ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d62a86fc4a9075719386ebc7d3356ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.tag','data' => ['class' => 'w-4 h-4 mr-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.tag'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d62a86fc4a9075719386ebc7d3356ae)): ?>
<?php $attributes = $__attributesOriginal9d62a86fc4a9075719386ebc7d3356ae; ?>
<?php unset($__attributesOriginal9d62a86fc4a9075719386ebc7d3356ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d62a86fc4a9075719386ebc7d3356ae)): ?>
<?php $component = $__componentOriginal9d62a86fc4a9075719386ebc7d3356ae; ?>
<?php unset($__componentOriginal9d62a86fc4a9075719386ebc7d3356ae); ?>
<?php endif; ?>
        Set Priority
        <?php if (isset($component)) { $__componentOriginalc908c1599f75cbbe95349a183df29a7a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc908c1599f75cbbe95349a183df29a7a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.chevron-down','data' => ['class' => 'w-4 h-4 ml-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.chevron-down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 ml-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc908c1599f75cbbe95349a183df29a7a)): ?>
<?php $attributes = $__attributesOriginalc908c1599f75cbbe95349a183df29a7a; ?>
<?php unset($__attributesOriginalc908c1599f75cbbe95349a183df29a7a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc908c1599f75cbbe95349a183df29a7a)): ?>
<?php $component = $__componentOriginalc908c1599f75cbbe95349a183df29a7a; ?>
<?php unset($__componentOriginalc908c1599f75cbbe95349a183df29a7a); ?>
<?php endif; ?>
    </button>
    
    <div id="priority-dropdown" class="hidden absolute right-0 mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-50 border border-gray-200 dark:border-gray-700">
        <div class="py-1">
            <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" onclick="bulkSetPriority('<?php echo e($key); ?>')" 
                        class="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                    <span class="inline-block w-3 h-3 bg-<?php echo e($priority['color']); ?>-400 rounded-full mr-2"></span>
                    <?php echo e($priority['label']); ?>

                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script>
function togglePriorityDropdown() {
    const dropdown = document.getElementById('priority-dropdown');
    dropdown.classList.toggle('hidden');
    
    // Close other dropdown
    document.getElementById('more-actions-dropdown')?.classList.add('hidden');
}
</script><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/bulk-actions/priority-dropdown.blade.php ENDPATH**/ ?>