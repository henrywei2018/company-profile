
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Dashboard',
    'enableCharts' => false,
    'unreadMessages' => 0,
    'pendingQuotations' => 0,
    'recentNotifications' => null,
    'unreadNotificationsCount' => 0,
    'unreadMessagesCount' => 0,
    'pendingQuotationsCount' => 0,
    'waitingChatsCount' => 0,
    'urgentItemsCount' => 0
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Dashboard',
    'enableCharts' => false,
    'unreadMessages' => 0,
    'pendingQuotations' => 0,
    'recentNotifications' => null,
    'unreadNotificationsCount' => 0,
    'unreadMessagesCount' => 0,
    'pendingQuotationsCount' => 0,
    'waitingChatsCount' => 0,
    'urgentItemsCount' => 0
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('meta'); ?>
    <?php if(auth()->guard()->check()): ?>
        <meta name="auth-user-id" content="<?php echo e(auth()->id()); ?>">
        <meta name="is-admin" content="<?php echo e(auth()->user()->hasRole(['admin', 'super-admin']) ? 'true' : 'false'); ?>">
    <?php endif; ?>

    <title><?php echo e($title); ?> - Admin Panel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-VYHSLQXJE5"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-VYHSLQXJE5');
    </script>
    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Custom Styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>

    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script>
        // Quick theme check before page load to prevent flashing
        const html = document.querySelector('html');
        const isLightOrAuto = localStorage.getItem('hs_theme') === 'light' || (localStorage.getItem('hs_theme') ===
            'auto' && !window.matchMedia('(prefers-color-scheme: dark)').matches);
        const isDarkOrAuto = localStorage.getItem('hs_theme') === 'dark' || (localStorage.getItem('hs_theme') === 'auto' &&
            window.matchMedia('(prefers-color-scheme: dark)').matches);

        if (isLightOrAuto && html.classList.contains('dark')) html.classList.remove('dark');
        else if (isDarkOrAuto && html.classList.contains('light')) html.classList.remove('light');
        else if (isDarkOrAuto && !html.classList.contains('dark')) html.classList.add('dark');
        else if (isLightOrAuto && !html.classList.contains('light')) html.classList.add('light');
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>

</head>

<body class="bg-gray-50 dark:bg-neutral-900">
    <!-- ========== HEADER ========== -->
    <?php if (isset($component)) { $__componentOriginal25a8eb218b7b1f8d758959b05d761961 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25a8eb218b7b1f8d758959b05d761961 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.admin-header','data' => ['unreadMessagesCount' => $unreadMessagesCount ?? 0,'pendingQuotationsCount' => $pendingQuotationsCount ?? 0,'recentNotifications' => $recentNotifications ?? collect(),'unreadNotificationsCount' => $unreadNotificationsCount ?? 0,'waitingChatsCount' => $waitingChatsCount ?? 0,'urgentItemsCount' => $urgentItemsCount ?? 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.admin-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['unreadMessagesCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($unreadMessagesCount ?? 0),'pendingQuotationsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingQuotationsCount ?? 0),'recentNotifications' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentNotifications ?? collect()),'unreadNotificationsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($unreadNotificationsCount ?? 0),'waitingChatsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($waitingChatsCount ?? 0),'urgentItemsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($urgentItemsCount ?? 0)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25a8eb218b7b1f8d758959b05d761961)): ?>
<?php $attributes = $__attributesOriginal25a8eb218b7b1f8d758959b05d761961; ?>
<?php unset($__attributesOriginal25a8eb218b7b1f8d758959b05d761961); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25a8eb218b7b1f8d758959b05d761961)): ?>
<?php $component = $__componentOriginal25a8eb218b7b1f8d758959b05d761961; ?>
<?php unset($__componentOriginal25a8eb218b7b1f8d758959b05d761961); ?>
<?php endif; ?>
    <!-- ========== END HEADER ========== -->

    <!-- ========== MAIN CONTENT ========== -->
    <!-- Mobile breadcrumb -->
    <?php if (isset($component)) { $__componentOriginal543003e24025a5aa3bec508f88c5905c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal543003e24025a5aa3bec508f88c5905c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.mobile-breadcrumb','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.mobile-breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal543003e24025a5aa3bec508f88c5905c)): ?>
<?php $attributes = $__attributesOriginal543003e24025a5aa3bec508f88c5905c; ?>
<?php unset($__attributesOriginal543003e24025a5aa3bec508f88c5905c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal543003e24025a5aa3bec508f88c5905c)): ?>
<?php $component = $__componentOriginal543003e24025a5aa3bec508f88c5905c; ?>
<?php unset($__componentOriginal543003e24025a5aa3bec508f88c5905c); ?>
<?php endif; ?>

    <!-- Sidebar -->
    <?php if (isset($component)) { $__componentOriginalce68f767967e97434710d01523e02fcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce68f767967e97434710d01523e02fcd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.admin-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce68f767967e97434710d01523e02fcd)): ?>
<?php $attributes = $__attributesOriginalce68f767967e97434710d01523e02fcd; ?>
<?php unset($__attributesOriginalce68f767967e97434710d01523e02fcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce68f767967e97434710d01523e02fcd)): ?>
<?php $component = $__componentOriginalce68f767967e97434710d01523e02fcd; ?>
<?php unset($__componentOriginalce68f767967e97434710d01523e02fcd); ?>
<?php endif; ?>

    <!-- Content -->
    <div class="w-full lg:ps-64">
        <div class="p-4 sm:p-6 space-y-4 sm:space-y-6">
            <!-- Flash Messages -->
            <?php if(session('success')): ?>
                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'success','class' => 'mb-4','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','class' => 'mb-4','dismissible' => true]); ?>
                    <?php echo e(session('success')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'error','class' => 'mb-4','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error','class' => 'mb-4','dismissible' => true]); ?>
                    <?php echo e(session('error')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
            <?php endif; ?>

            <?php if(session('info')): ?>
                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'info','class' => 'mb-4','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'info','class' => 'mb-4','dismissible' => true]); ?>
                    <?php echo e(session('info')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
            <?php endif; ?>

            <?php if(session('warning')): ?>
                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'warning','class' => 'mb-4','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning','class' => 'mb-4','dismissible' => true]); ?>
                    <?php echo e(session('warning')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
            <?php endif; ?>

            <!-- Error Display (if any from controller) -->
            <?php if(isset($error)): ?>
                <div class="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-red-800">Dashboard Error</h3>
                            <div class="mt-2 text-sm text-red-700"><?php echo e($error); ?></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Page Content -->
            <?php echo e($slot); ?>

        </div>
    </div>
    
    <!-- Chat Widget for Admins -->
    
    
    <!-- ========== END MAIN CONTENT ========== -->

    <!-- Global JavaScript -->
    
    <script>
        


        // Global error handler for admin
        window.addEventListener('error', function(e) {
            console.error('Admin global error:', e.error);
        });

        // Global unhandled promise rejection handler
        window.addEventListener('unhandledrejection', function(e) {
            console.error('Admin unhandled promise rejection:', e.reason);
        });

        // Auto-refresh admin stats every minute
        document.addEventListener('DOMContentLoaded', function() {
            setInterval(function() {
                updateAdminStats();
            }, 60000); // Every minute for admin
        });

        function updateAdminStats() {
            fetch('<?php echo e(route("admin.dashboard.stats")); ?>')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update various admin counters
                    updateAdminCounters(data.data);
                }
            })
            .catch(error => console.error('Error updating admin stats:', error));
        }

        function updateAdminCounters(data) {
            // Update notification badge
            if (data.notifications && typeof updateAdminNotificationBadge === 'function') {
                updateAdminNotificationBadge(data.notifications.unread);
            }
            
            // Update other counters if elements exist
            const elements = {
                'pending-quotations-count': data.quotations?.pending,
                'waiting-chats-count': data.chat?.waiting,
                'unread-messages-count': data.messages?.unread,
                'urgent-items-count': data.urgent_items
            };

            Object.entries(elements).forEach(([elementId, value]) => {
                const element = document.getElementById(elementId);
                if (element && value !== undefined) {
                    element.textContent = value;
                    
                    // Show/hide based on value
                    if (value > 0) {
                        element.style.display = 'inline-flex';
                    } else {
                        element.style.display = 'none';
                    }
                }
            });
        }

        // Admin-specific helper functions
        function handleAdminError(error, context = 'admin') {
            console.error(`Admin error in ${context}:`, error);
            
            // Show user-friendly error message
            const errorContainer = document.getElementById('admin-error-container');
            if (errorContainer) {
                errorContainer.innerHTML = `
                    <div class="bg-red-50 border border-red-200 rounded-md p-4 mb-4">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <svg class="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                                </svg>
                            </div>
                            <div class="ml-3">
                                <h3 class="text-sm font-medium text-red-800">Admin System Notice</h3>
                                <div class="mt-2 text-sm text-red-700">
                                    Some admin features may be temporarily unavailable. Please refresh the page or contact system administrator.
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }
        }

        // System health check for admin
        function checkSystemHealth() {
            fetch('<?php echo e(route("admin.dashboard.system-health")); ?>')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateSystemHealthIndicator(data.overall_status);
                }
            })
            .catch(error => {
                console.error('System health check failed:', error);
                updateSystemHealthIndicator('error');
            });
        }

        function updateSystemHealthIndicator(status) {
            const indicator = document.getElementById('system-health-indicator');
            if (indicator) {
                indicator.className = `system-health-${status}`;
                indicator.title = `System Status: ${status}`;
            }
        }

        // Run system health check every 5 minutes for admin
        document.addEventListener('DOMContentLoaded', function() {
            checkSystemHealth();
            setInterval(checkSystemHealth, 300000); // 5 minutes
        });

        
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/layouts/admin.blade.php ENDPATH**/ ?>