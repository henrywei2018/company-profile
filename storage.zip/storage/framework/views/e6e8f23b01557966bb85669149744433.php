
<?php if (isset($component)) { $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.public','data' => ['title' => $siteConfig['site_title'],'description' => $siteConfig['site_description'],'keywords' => $siteConfig['site_keywords'],'bodyClass' => 'homepage']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.public'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siteConfig['site_title']),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siteConfig['site_description']),'keywords' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siteConfig['site_keywords']),'bodyClass' => 'homepage']); ?>


<?php if($heroBanners && $heroBanners->count() > 0): ?>
<section class="hero-section relative min-h-screen overflow-hidden">
    <div class="hero-slider relative h-screen">
        <?php $__currentLoopData = $heroBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="hero-slide absolute inset-0 <?php echo e($index === 0 ? 'opacity-100' : 'opacity-0'); ?> transition-opacity duration-1000">
                <div class="absolute inset-0 bg-black bg-opacity-40 z-10"></div>
                
                <?php if($banner->image): ?>
                    <img 
                        src="<?php echo e(Storage::url($banner->image)); ?>" 
                        alt="<?php echo e($banner->title); ?>"
                        class="w-full h-full object-cover"
                        loading="<?php echo e($index === 0 ? 'eager' : 'lazy'); ?>"
                    >
                <?php else: ?>
                    <div class="w-full h-full bg-gradient-to-br from-orange-600 to-amber-600"></div>
                <?php endif; ?>
                
                <div class="absolute inset-0 z-20 flex items-center justify-center">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
                        <h1 class="text-5xl md:text-7xl font-bold mb-6 animate-fade-in-up">
                            <?php echo e($banner->title); ?>

                        </h1>
                        
                        <?php if($banner->description): ?>
                            <p class="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed animate-fade-in-up animation-delay-300">
                                <?php echo e($banner->description); ?>

                            </p>
                        <?php endif; ?>
                        
                        <?php if($banner->button_text && $banner->button_link): ?>
                            <div class="animate-fade-in-up animation-delay-600">
                                <a href="<?php echo e($banner->button_link); ?>" 
                                   class="cta-button inline-flex items-center px-8 py-4 bg-orange-600 text-white font-semibold rounded-xl hover:bg-orange-700 transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl">
                                    <?php echo e($banner->button_text); ?>

                                    <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                                    </svg>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    
    <?php if($heroBanners->count() > 1): ?>
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-30">
            <div class="flex space-x-2">
                <?php $__currentLoopData = $heroBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button 
                        class="hero-dot w-3 h-3 rounded-full transition-all duration-300 <?php echo e($index === 0 ? 'bg-white' : 'bg-white bg-opacity-50'); ?>"
                        onclick="switchHeroSlide(<?php echo e($index); ?>)"
                    ></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
    
    
    <?php if($stats): ?>
        <div class="floating-stats absolute bottom-20 right-8 hidden lg:block">
            <div class="bg-white bg-opacity-95 backdrop-blur-sm rounded-2xl p-6 shadow-2xl animate-float">
                <div class="grid grid-cols-2 gap-4 text-center">
                    <div>
                        <div class="text-3xl font-bold text-orange-600"><?php echo e($stats['completed_projects']); ?>+</div>
                        <div class="text-sm text-gray-600">Projects</div>
                    </div>
                    <div>
                        <div class="text-3xl font-bold text-orange-600"><?php echo e($stats['happy_clients']); ?>+</div>
                        <div class="text-sm text-gray-600">Clients</div>
                    </div>
                    <div>
                        <div class="text-3xl font-bold text-orange-600"><?php echo e($stats['years_experience']); ?>+</div>
                        <div class="text-sm text-gray-600">Years</div>
                    </div>
                    <div>
                        <div class="text-3xl font-bold text-orange-600"><?php echo e($stats['active_services']); ?>+</div>
                        <div class="text-sm text-gray-600">Services</div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</section>
<?php else: ?>

<section class="hero-section bg-gradient-to-br from-orange-600 to-amber-600 min-h-screen flex items-center justify-center text-white relative overflow-hidden">
    <div class="absolute inset-0 bg-black bg-opacity-20"></div>
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 class="text-5xl md:text-7xl font-bold mb-6 animate-fade-in-up">
            <?php echo e($siteConfig['site_title']); ?>

        </h1>
        <p class="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed animate-fade-in-up animation-delay-300">
            <?php echo e($siteConfig['site_description']); ?>

        </p>
        <div class="animate-fade-in-up animation-delay-600">
            <a href="<?php echo e(route('services.index')); ?>" 
               class="cta-button inline-flex items-center px-8 py-4 bg-white text-orange-600 font-semibold rounded-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl">
                Explore Our Services
                <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                </svg>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($stats): ?>
<section class="py-16 bg-gray-50 lg:hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="stats-grid grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div class="animate-in">
                <div class="text-4xl md:text-5xl font-bold text-orange-600 mb-2"><?php echo e($stats['completed_projects']); ?>+</div>
                <div class="text-gray-600 font-medium">Completed Projects</div>
            </div>
            <div class="animate-in animation-delay-200">
                <div class="text-4xl md:text-5xl font-bold text-orange-600 mb-2"><?php echo e($stats['happy_clients']); ?>+</div>
                <div class="text-gray-600 font-medium">Happy Clients</div>
            </div>
            <div class="animate-in animation-delay-400">
                <div class="text-4xl md:text-5xl font-bold text-orange-600 mb-2"><?php echo e($stats['years_experience']); ?>+</div>
                <div class="text-gray-600 font-medium">Years Experience</div>
            </div>
            <div class="animate-in animation-delay-600">
                <div class="text-4xl md:text-5xl font-bold text-orange-600 mb-2"><?php echo e($stats['active_services']); ?>+</div>
                <div class="text-gray-600 font-medium">Services</div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($companyProfile): ?>
<section class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            <div class="animate-fade-in-left">
                <h2 class="text-4xl font-bold text-gray-900 mb-6">
                    Why Choose 
                    <span class="text-orange-600"><?php echo e($companyProfile->company_name ?? config('app.name')); ?></span>?
                </h2>
                
                <?php if($companyProfile->about_us): ?>
                    <p class="text-lg text-gray-600 mb-8 leading-relaxed">
                        <?php echo e(Str::limit($companyProfile->about_us, 300)); ?>

                    </p>
                <?php endif; ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div class="flex items-start space-x-3">
                        <div class="flex-shrink-0 w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center mt-1">
                            <svg class="w-4 h-4 text-orange-600" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-900">Professional Excellence</h4>
                            <p class="text-gray-600">Delivering quality solutions with expert precision</p>
                        </div>
                    </div>
                    
                    <div class="flex items-start space-x-3">
                        <div class="flex-shrink-0 w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center mt-1">
                            <svg class="w-4 h-4 text-orange-600" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-900">Trusted Partnership</h4>
                            <p class="text-gray-600">Building lasting relationships with every client</p>
                        </div>
                    </div>
                </div>
                
                <a href="<?php echo e(route('about.index')); ?>" 
                   class="inline-flex items-center px-6 py-3 border-2 border-orange-600 text-orange-600 font-semibold rounded-lg hover:bg-orange-600 hover:text-white transition-all duration-300">
                    Learn More About Us
                    <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                    </svg>
                </a>
            </div>
            
            
            <div class="animate-fade-in-right">
                    <img 
                        src="https://picsum.photos/id/1/200/300" 
                        alt="<?php echo e($companyProfile->company_name); ?>"
                        class="w-full h-200 rounded-2xl shadow-2xl"
                        loading="lazy"
                    >
            </div>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($featuredServices && $featuredServices->count() > 0): ?>
<section class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4 animate-in">Our Services</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto animate-in animation-delay-200">
                Comprehensive solutions tailored to meet your business needs with professional excellence.
            </p>
        </div>
        
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__currentLoopData = $featuredServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="service-card bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-in" style="animation-delay: <?php echo e($index * 200); ?>ms;">
                    
                    <div class="w-16 h-16 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <?php if($service->icon): ?>
                            <img src="<?php echo e(asset('storage/' . $service->icon)); ?>" alt="<?php echo e($service->name); ?> Icon" class="w-16 h-16 object-contain" />
                        <?php else: ?>
                            <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M6 6V5a3 3 0 013-3h2a3 3 0 013 3v1h2a2 2 0 012 2v3.57A22.952 22.952 0 0110 13a22.95 22.95 0 01-8-1.43V8a2 2 0 012-2h2zm2-1a1 1 0 011-1h2a1 1 0 011 1v1H8V5zm1 5a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1z" clip-rule="evenodd"/>
                                <path d="M2 13.692V16a2 2 0 002 2h12a2 2 0 002-2v-2.308A24.974 24.974 0 0110 15c-2.796 0-5.487-.46-8-1.308z"/>
                            </svg>
                        <?php endif; ?>
                    </div>
                    
                    
                    <h3 class="text-xl font-semibold text-gray-900 mb-3"><?php echo e($service->name); ?></h3>
                    <p class="text-gray-600 mb-6 leading-relaxed">
                        <?php echo e(Str::limit($service->description, 120)); ?>

                    </p>
                    
                    
                    <a href="<?php echo e(route('services.show', $service->slug)); ?>" 
                       class="inline-flex items-center text-orange-600 font-medium hover:text-orange-700 transition-colors duration-300 group">
                        Learn More
                        <svg class="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                        </svg>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        
        <div class="text-center mt-12">
            <a href="<?php echo e(route('services.index')); ?>" 
               class="inline-flex items-center px-8 py-4 bg-orange-600 text-white font-semibold rounded-xl hover:bg-orange-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                View All Services
                <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                </svg>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($featuredProjects && $featuredProjects->count() > 0): ?>
<section class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4 animate-in">Our Recent Work</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto animate-in animation-delay-200">
                Explore our portfolio of successful projects that showcase our expertise and commitment to excellence.
            </p>
        </div>
        
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__currentLoopData = $featuredProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="project-card group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-in" style="animation-delay: <?php echo e($index * 200); ?>ms;">
                    
                    
                    <div class="relative overflow-hidden h-64">
                        <?php if($project->featured_image_url): ?>
        <img src="<?php echo e($project->featured_image_url); ?>"
            alt="<?php echo e($project->title); ?>"
            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            loading="lazy"
        >
    <?php else: ?>
        <div class="w-full h-full bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center">
            <svg class="w-16 h-16 text-orange-300" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
            </svg>
        </div>
    <?php endif; ?>
                        
                        
                        <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                            <a href="<?php echo e(route('portfolio.show', $project->slug)); ?>" 
                               class="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-white text-orange-600 px-6 py-3 rounded-lg font-semibold hover:bg-orange-50 transform translate-y-4 group-hover:translate-y-0">
                                View Project
                            </a>
                        </div>
                    </div>
                    
                    
                    <div class="p-6">
                        
                        <?php if($project->category): ?>
                            <span class="inline-block px-3 py-1 bg-orange-100 text-orange-600 text-sm font-medium rounded-full mb-3">
                                <?php echo e($project->category->name); ?>

                            </span>
                        <?php endif; ?>
                        
                        
                        <h3 class="text-xl font-semibold text-gray-900 mb-3 group-hover:text-orange-600 transition-colors duration-300">
                            <a href="<?php echo e(route('portfolio.show', $project->slug)); ?>">
                                <?php echo e($project->title); ?>

                            </a>
                        </h3>
                        
                        
                        <?php if($project->excerpt): ?>
                            <p class="text-gray-600 leading-relaxed mb-4 line-clamp-3">
                                <?php echo e($project->excerpt); ?>

                            </p>
                        <?php elseif($project->description): ?>
                            <p class="text-gray-600 leading-relaxed mb-4 line-clamp-3">
                                <?php echo e(Str::limit(strip_tags($project->description), 120)); ?>

                            </p>
                        <?php endif; ?>
                        
                        
                        <div class="flex items-center justify-between text-sm text-gray-500">
                            
                            <?php if($project->client): ?>
                                <div class="flex items-center">
                                    <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php echo e($project->client->name); ?>

                                </div>
                            <?php endif; ?>
                            
                            
                            <?php if($project->completed_at): ?>
                                <div>
                                    <?php echo e($project->completed_at->format('M Y')); ?>

                                </div>
                            <?php elseif($project->status): ?>
                                <div class="px-2 py-1 rounded text-xs <?php echo e($project->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $project->status))); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        
        <div class="text-center mt-12">
            <a href="<?php echo e(route('portfolio.index')); ?>" 
               class="inline-flex items-center px-8 py-4 bg-orange-600 text-white font-semibold rounded-xl hover:bg-orange-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                View All Projects
                <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                </svg>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if(isset($featuredProducts) && $featuredProducts && $featuredProducts->count() > 0): ?>
<section class="py-20 bg-gradient-to-br from-orange-50 via-white to-amber-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4 animate-in">Featured Products</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto animate-in animation-delay-200">
                Discover our top-quality construction and engineering products designed to meet your project requirements.
            </p>
        </div>
        
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__currentLoopData = $featuredProducts->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-card group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate-in" style="animation-delay: <?php echo e($index * 200); ?>ms;">
                    
                    <div class="relative overflow-hidden h-64">
                        <?php
                                            // Get the main image (featured or first image)
                                            $mainImage =
                                                $product->images->where('is_featured', true)->first() ?:
                                                $product->images->first();
                                        ?>

                                        <?php if($mainImage): ?>
                                            <img src="<?php echo e($mainImage->image_url); ?>"
                                                alt="<?php echo e($mainImage->alt_text ?: $product->name); ?>"
                                                class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                                        <?php else: ?>
                                            <div
                                                class="w-full h-full bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center">
                                                <svg class="w-16 h-16 text-orange-400" fill="none"
                                                    stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="1"
                                                        d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                                                </svg>
                                            </div>
                                        <?php endif; ?>
                        
                        
                        <div class="absolute top-3 left-3 flex flex-col space-y-2">
                            <span class="bg-amber-500 text-white px-2 py-1 rounded-lg text-xs font-medium">
                                Featured
                            </span>
                            
                            <?php if($product->stock_status === 'in_stock'): ?>
                            <span class="bg-green-500 text-white px-2 py-1 rounded-lg text-xs font-medium">
                                In Stock
                            </span>
                            <?php elseif($product->stock_status === 'out_of_stock'): ?>
                            <span class="bg-red-500 text-white px-2 py-1 rounded-lg text-xs font-medium">
                                Out of Stock
                            </span>
                            <?php endif; ?>
                        </div>

                        
                        <?php if($product->category): ?>
                        <div class="absolute top-3 right-3">
                            <span class="bg-white/90 text-gray-800 px-2 py-1 rounded-lg text-xs font-medium">
                                <?php echo e($product->category->name); ?>

                            </span>
                        </div>
                        <?php endif; ?>
                        
                        
                        <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                            <a href="<?php echo e(route('products.show', $product->slug)); ?>" 
                               class="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-white text-amber-600 px-6 py-3 rounded-lg font-semibold hover:bg-amber-50 transform translate-y-4 group-hover:translate-y-0">
                                View Product
                            </a>
                        </div>
                    </div>
                    
                    
                    <div class="p-6">
                        
                        <?php if($product->brand): ?>
                            <div class="text-sm text-amber-600 font-medium mb-2"><?php echo e($product->brand); ?></div>
                        <?php endif; ?>
                        
                        
                        <h3 class="text-xl font-semibold text-gray-900 mb-3 group-hover:text-amber-600 transition-colors duration-300 line-clamp-2">
                            <a href="<?php echo e(route('products.show', $product->slug)); ?>">
                                <?php echo e($product->name); ?>

                            </a>
                        </h3>
                        
                        
                        <?php if($product->short_description): ?>
                            <p class="text-gray-600 leading-relaxed mb-4 line-clamp-3">
                                <?php echo e($product->short_description); ?>

                            </p>
                        <?php endif; ?>
                        
                        
                        <div class="flex items-center justify-between">
                            <div class="text-lg font-bold text-amber-600">
                                <?php echo $product->formatted_price; ?>

                            </div>
                            
                            <a href="<?php echo e(route('products.show', $product->slug)); ?>" 
                               class="text-amber-600 hover:text-amber-700 font-medium text-sm">
                                View Details →
                            </a>
                        </div>
                    </div>
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        
        <div class="text-center mt-12">
            <a href="<?php echo e(route('products.index')); ?>" 
               class="inline-flex items-center px-8 py-4 bg-amber-600 text-white font-semibold rounded-xl hover:bg-amber-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                View All Products
                <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                </svg>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if($testimonials && $testimonials->count() > 0): ?>
<section class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4 animate-in">What Our Clients Say</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto animate-in animation-delay-200">
                Don't just take our word for it. Here's what our satisfied clients have to say about our services.
            </p>
        </div>
        
        
        <div class="testimonials-container overflow-x-auto pb-6">
            <div class="flex space-x-8 min-w-max">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testimonial-card flex-shrink-0 w-96 bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 animate-in" style="animation-delay: <?php echo e($index * 200); ?>ms;">
                        
                        <div class="flex items-center mb-6">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <svg class="w-5 h-5 <?php echo e($i <= ($testimonial->rating ?? 5) ? 'text-yellow-400' : 'text-gray-300'); ?>" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                </svg>
                            <?php endfor; ?>
                        </div>
                        
                        
                        <blockquote class="text-gray-700 mb-6 leading-relaxed italic">
                            "<?php echo e($testimonial->content); ?>"
                        </blockquote>
                        
                        
                        <div class="flex items-center">
                            <?php if($testimonial->client_photo): ?>
                                <img 
                                    src="<?php echo e(Storage::url($testimonial->client_photo)); ?>" 
                                    alt="<?php echo e($testimonial->client_name); ?>"
                                    class="w-12 h-12 rounded-full object-cover mr-4"
                                    loading="lazy"
                                >
                            <?php else: ?>
                                <div class="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mr-4">
                                    <span class="text-orange-600 font-semibold text-lg">
                                        <?php echo e(substr($testimonial->client_name, 0, 1)); ?>

                                    </span>
                                </div>
                            <?php endif; ?>
                            
                            <div>
                                <h4 class="font-semibold text-gray-900"><?php echo e($testimonial->client_name); ?></h4>
                                <?php if($testimonial->client_company): ?>
                                    <p class="text-sm text-gray-600"><?php echo e($testimonial->client_company); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>


<section class="py-20 bg-gradient-to-br from-orange-600 to-amber-600 text-white relative overflow-hidden">
    <div class="absolute inset-0 bg-black bg-opacity-20"></div>
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 class="text-4xl md:text-5xl font-bold mb-6 animate-in">
            Ready to Start Your Project?
        </h2>
        <p class="text-xl mb-8 max-w-3xl mx-auto leading-relaxed animate-in animation-delay-200">
            Get in touch with our team today and let's discuss how we can help bring your vision to life with our professional services.
        </p>
        
        <div class="flex flex-col sm:flex-row gap-4 justify-center animate-in animation-delay-400">
            <a href="<?php echo e(route('contact.index')); ?>" 
               class="inline-flex items-center px-8 py-4 bg-white text-orange-600 font-semibold rounded-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                Contact Us Today
                <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                </svg>
            </a>
            
        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
// Hero Slider Functionality
let currentSlide = 0;
const slides = document.querySelectorAll('.hero-slide');
const dots = document.querySelectorAll('.hero-dot');

function switchHeroSlide(index) {
    // Hide current slide
    if (slides[currentSlide]) {
        slides[currentSlide].classList.remove('opacity-100');
        slides[currentSlide].classList.add('opacity-0');
    }
    
    // Update dots
    if (dots[currentSlide]) {
        dots[currentSlide].classList.remove('bg-white');
        dots[currentSlide].classList.add('bg-white', 'bg-opacity-50');
    }
    
    // Show new slide
    currentSlide = index;
    if (slides[currentSlide]) {
        slides[currentSlide].classList.remove('opacity-0');
        slides[currentSlide].classList.add('opacity-100');
    }
    
    // Update active dot
    if (dots[currentSlide]) {
        dots[currentSlide].classList.remove('bg-opacity-50');
        dots[currentSlide].classList.add('bg-white');
    }
}

// Auto slide functionality
if (slides.length > 1) {
    setInterval(() => {
        const nextSlide = (currentSlide + 1) % slides.length;
        switchHeroSlide(nextSlide);
    }, 5000);
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
        }
    });
}, observerOptions);

// Observe all elements with animation classes
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.animate-fade-in-up, .animate-fade-in-left, .animate-fade-in-right, .animate-in');
    animatedElements.forEach(el => observer.observe(el));
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $attributes = $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $component = $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/pages/home.blade.php ENDPATH**/ ?>