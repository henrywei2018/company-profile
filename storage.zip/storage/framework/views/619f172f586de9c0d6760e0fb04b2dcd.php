
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'src',
    'alt' => 'Preview',
    'width' => 'w-20',
    'height' => 'h-12',
    'fallbackIcon' => 'image',
    'rounded' => 'rounded-lg',
    'objectFit' => 'object-cover'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'src',
    'alt' => 'Preview',
    'width' => 'w-20',
    'height' => 'h-12',
    'fallbackIcon' => 'image',
    'rounded' => 'rounded-lg',
    'objectFit' => 'object-cover'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php if($src): ?>
    <img src="<?php echo e($src); ?>" 
         alt="<?php echo e($alt); ?>" 
         class="<?php echo e($width); ?> <?php echo e($height); ?> <?php echo e($objectFit); ?> <?php echo e($rounded); ?> flex-shrink-0">
<?php else: ?>
    <div class="<?php echo e($width); ?> <?php echo e($height); ?> bg-gray-200 dark:bg-gray-700 <?php echo e($rounded); ?> flex items-center justify-center flex-shrink-0">
        <?php if($fallbackIcon === 'image'): ?>
            <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
            </svg>
        <?php elseif($fallbackIcon === 'document'): ?>
            <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
        <?php elseif($fallbackIcon === 'video'): ?>
            <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
            </svg>
        <?php else: ?>
            <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
            </svg>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/media-preview.blade.php ENDPATH**/ ?>