
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'status',
    'size' => 'sm', // xs, sm, md, lg
    'statusMap' => []
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'status',
    'size' => 'sm', // xs, sm, md, lg
    'statusMap' => []
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
$defaultStatusMap = [
    'active' => [
        'label' => 'Active',
        'class' => 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
    ],
    'inactive' => [
        'label' => 'Inactive',
        'class' => 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100'
    ],
    'pending' => [
        'label' => 'Pending',
        'class' => 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
    ],
    'published' => [
        'label' => 'Published',
        'class' => 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
    ],
    'draft' => [
        'label' => 'Draft',
        'class' => 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
    ],
    'archived' => [
        'label' => 'Archived',
        'class' => 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
    ],
    'scheduled' => [
        'label' => 'Scheduled',
        'class' => 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100'
    ],
    'expired' => [
        'label' => 'Expired',
        'class' => 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
    ],
    'live' => [
        'label' => 'Live',
        'class' => 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
    ]
];

$mergedStatusMap = array_merge($defaultStatusMap, $statusMap);
$statusConfig = $mergedStatusMap[$status] ?? [
    'label' => ucfirst($status),
    'class' => 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100'
];

$sizeClasses = [
    'xs' => 'px-1.5 py-0.5 text-xs',
    'sm' => 'px-2 py-0.5 text-xs',
    'md' => 'px-2.5 py-1 text-sm',
    'lg' => 'px-3 py-1.5 text-base'
];

$sizeClass = $sizeClasses[$size] ?? $sizeClasses['sm'];
?>

<span class="inline-flex items-center <?php echo e($sizeClass); ?> rounded-full font-medium <?php echo e($statusConfig['class']); ?>">
    <?php echo e($statusConfig['label']); ?>

</span><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/status-badge.blade.php ENDPATH**/ ?>