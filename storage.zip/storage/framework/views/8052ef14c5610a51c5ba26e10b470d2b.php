<!-- resources/views/client/messages/create.blade.php -->
<?php if (isset($component)) { $__componentOriginalc1a79cbe563a13156ed4a05a5df23f77 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1a79cbe563a13156ed4a05a5df23f77 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.client','data' => ['title' => 'New Message','unreadMessages' => 0,'pendingQuotations' => 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.client'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'New Message','unreadMessages' => 0,'pendingQuotations' => 0]); ?>
    <!-- Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <?php if (isset($component)) { $__componentOriginaldbbc880c47f621cda59b70d6eb356b2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbbc880c47f621cda59b70d6eb356b2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.breadcrumb','data' => ['items' => [
            'Messages' => route('client.messages.index'),
            'New Message' => '#',
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            'Messages' => route('client.messages.index'),
            'New Message' => '#',
        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbbc880c47f621cda59b70d6eb356b2f)): ?>
<?php $attributes = $__attributesOriginaldbbc880c47f621cda59b70d6eb356b2f; ?>
<?php unset($__attributesOriginaldbbc880c47f621cda59b70d6eb356b2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbbc880c47f621cda59b70d6eb356b2f)): ?>
<?php $component = $__componentOriginaldbbc880c47f621cda59b70d6eb356b2f; ?>
<?php unset($__componentOriginaldbbc880c47f621cda59b70d6eb356b2f); ?>
<?php endif; ?>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Form -->
        <div class="lg:col-span-2">
            <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> Send New Message <?php $__env->endSlot(); ?>
                 <?php $__env->slot('subtitle', null, []); ?> Get in touch with our support team <?php $__env->endSlot(); ?>

                <form action="<?php echo e(route('client.messages.store')); ?>" method="POST" enctype="multipart/form-data"
                    id="message-form">
                    <?php echo csrf_field(); ?>

                    <div class="space-y-6">
                        <!-- Subject -->
                        <div>
                            <label for="subject"
                                class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Subject <span class="text-red-500">*</span>
                            </label>
                            <input type="text" id="subject" name="subject" required maxlength="255"
                                placeholder="Brief description of your inquiry"
                                value="<?php echo e(old('subject', $prefillData['subject'] ?? '')); ?>"
                                class="block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Type and Priority Row -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <!-- Message Type -->
                            <input type="hidden" name="type" value="client_to_admin">
                            <?php if($projects->count() > 0): ?>
                            <div>
                                <label for="project_id"
                                    class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Related Project (Optional)
                                </label>
                                <select id="project_id" name="project_id"
                                    class="block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                                    <option value="">No specific project</option>
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($project->id); ?>"
                                            <?php echo e(old('project_id', $prefillData['project_id'] ?? '') == $project->id ? 'selected' : ''); ?>>
                                            <?php echo e($project->title); ?> (<?php echo e(ucfirst($project->status)); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['project_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>

                            <!-- Priority -->
                            <div>
                                <label for="priority"
                                    class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Priority
                                </label>
                                <select id="priority" name="priority"
                                    class="block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm">
                                    
                                    <option value="normal"
                                        <?php echo e(old('priority', $prefillData['priority'] ?? 'normal') === 'normal' ? 'selected' : ''); ?>>
                                        Normal</option>
                                    <option value="urgent"
                                        <?php echo e(old('priority', $prefillData['priority'] ?? 'normal') === 'urgent' ? 'selected' : ''); ?>>
                                        Urgent</option>
                                </select>
                                <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Project Selection -->
                        

                        <!-- Message Content -->
                        <div>
                            <label for="message"
                                class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Message <span class="text-red-500">*</span>
                            </label>
                            <textarea id="message" name="message" rows="8" required maxlength="5000"
                                placeholder="Please describe your inquiry in detail..."
                                class="block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"><?php echo e(old('message')); ?></textarea>
                            <div class="flex justify-between mt-1">
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                                <?php else: ?>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">Be as detailed as possible to help
                                        us assist you better</p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <p class="text-sm text-gray-500 dark:text-gray-400">
                                    <span id="char-count">0</span>/5000
                                </p>
                            </div>
                        </div>

                        <!-- File Attachments -->
                        <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                            Attachments (Optional)
                        </label>
                        
                        <?php if (isset($component)) { $__componentOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.universal-file-uploader','data' => ['name' => 'files','multiple' => true,'maxFiles' => 5,'maxFileSize' => '10MB','acceptedFileTypes' => [
                                'image/jpeg', 'image/png', 'image/gif', 'image/webp',
                                'application/pdf',
                                'application/msword',
                                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                                'application/vnd.ms-excel',
                                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                'text/plain', 'text/csv',
                                'application/zip',
                                'application/x-rar-compressed'
                            ],'dropDescription' => 'Drop files here or click to browse','uploadEndpoint' => ''.e(route('client.messages.temp-upload')).'','deleteEndpoint' => ''.e(route('client.messages.temp-delete')).'','enableCategories' => false,'enableDescription' => false,'enablePublicToggle' => false,'autoUpload' => true,'uploadOnDrop' => true,'compact' => false,'theme' => 'default','id' => 'message-attachments']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('universal-file-uploader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'files','multiple' => true,'maxFiles' => 5,'maxFileSize' => '10MB','acceptedFileTypes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                                'image/jpeg', 'image/png', 'image/gif', 'image/webp',
                                'application/pdf',
                                'application/msword',
                                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                                'application/vnd.ms-excel',
                                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                'text/plain', 'text/csv',
                                'application/zip',
                                'application/x-rar-compressed'
                            ]),'dropDescription' => 'Drop files here or click to browse','uploadEndpoint' => ''.e(route('client.messages.temp-upload')).'','deleteEndpoint' => ''.e(route('client.messages.temp-delete')).'','enableCategories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'enableDescription' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'enablePublicToggle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'autoUpload' => true,'uploadOnDrop' => true,'compact' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'theme' => 'default','id' => 'message-attachments']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93)): ?>
<?php $attributes = $__attributesOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93; ?>
<?php unset($__attributesOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93)): ?>
<?php $component = $__componentOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93; ?>
<?php unset($__componentOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93); ?>
<?php endif; ?>
                        
                        <?php $__errorArgs = ['attachments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['attachments.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Hidden field to store uploaded file paths -->
                    <input type="hidden" name="temp_files" id="temp_files" value="">

                    <!-- Submit Button -->
                    <div class="flex justify-end">
                        <button type="submit" id="submit-btn"
                            class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                            </svg>
                            Send Message
                        </button>
                    </div>
                    </div>
                </form>
                <?php if($errors->any()): ?>
<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 mt-4">
    <strong>Validation Errors:</strong>
    <ul class="mt-2">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>• <?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Tips Card -->
            <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> 💡 Tips for Better Support <?php $__env->endSlot(); ?>

                <div class="space-y-3 text-sm text-gray-600 dark:text-gray-400">
                    <div class="flex items-start space-x-2">
                        <div class="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                        <p>Be specific about your issue or request</p>
                    </div>
                    <div class="flex items-start space-x-2">
                        <div class="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                        <p>Include relevant project details if applicable</p>
                    </div>
                    <div class="flex items-start space-x-2">
                        <div class="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                        <p>Attach screenshots or documents that help explain your issue</p>
                    </div>
                    <div class="flex items-start space-x-2">
                        <div class="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                        <p>Use "Urgent" priority only for critical issues</p>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>

            <!-- Response Time Info -->
            <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> 📞 Response Times <?php $__env->endSlot(); ?>

                <div class="space-y-3 text-sm">
                    <div class="flex items-center justify-between">
                        <span class="text-gray-600 dark:text-gray-400">Urgent:</span>
                        <span class="font-medium text-red-600 dark:text-red-400">Within 2 hours</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-gray-600 dark:text-gray-400">High:</span>
                        <span class="font-medium text-orange-600 dark:text-orange-400">Within 8 hours</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-gray-600 dark:text-gray-400">Normal:</span>
                        <span class="font-medium text-green-600 dark:text-green-400">Within 24 hours</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-gray-600 dark:text-gray-400">Low:</span>
                        <span class="font-medium text-gray-600 dark:text-gray-400">Within 48 hours</span>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>

            <!-- Recent Messages -->
            <?php if(!empty($recentMessages) && count($recentMessages) > 0): ?>
                <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('title', null, []); ?> 📨 Recent Messages <?php $__env->endSlot(); ?>

                    <div class="space-y-3">
                        <?php $__currentLoopData = array_slice($recentMessages, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentMessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="text-sm">
                                <a href="<?php echo e(route('client.messages.show', $recentMessage['id'])); ?>"
                                    class="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 font-medium">
                                    <?php echo e(Str::limit($recentMessage['title'], 40)); ?>

                                </a>
                                <p class="text-gray-500 dark:text-gray-400 text-xs mt-1">
                                    <?php echo e($recentMessage['created_at']); ?>

                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1a79cbe563a13156ed4a05a5df23f77)): ?>
<?php $attributes = $__attributesOriginalc1a79cbe563a13156ed4a05a5df23f77; ?>
<?php unset($__attributesOriginalc1a79cbe563a13156ed4a05a5df23f77); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1a79cbe563a13156ed4a05a5df23f77)): ?>
<?php $component = $__componentOriginalc1a79cbe563a13156ed4a05a5df23f77; ?>
<?php unset($__componentOriginalc1a79cbe563a13156ed4a05a5df23f77); ?>
<?php endif; ?>

<script>
    document.getElementById('message-form').addEventListener('submit', function(e) {
    console.log('Form submitting...');
    console.log('Subject:', document.getElementById('subject').value);
    console.log('Message length:', document.getElementById('message').value.length);
    console.log('Priority:', document.getElementById('priority').value);
    
    // Basic validation
    if (!document.getElementById('subject').value.trim()) {
        e.preventDefault();
        alert('Please enter a subject');
        return;
    }
    
    if (!document.getElementById('message').value.trim() || document.getElementById('message').value.trim().length < 10) {
        e.preventDefault();
        alert('Please enter a message (at least 10 characters)');
        return;
    }
    
    console.log('Form validation passed');
});
    // Character counter for message
    document.getElementById('message').addEventListener('input', function() {
        const charCount = this.value.length;
        document.getElementById('char-count').textContent = charCount;

        if (charCount > 4500) {
            document.getElementById('char-count').classList.add('text-red-500');
        } else {
            document.getElementById('char-count').classList.remove('text-red-500');
        }
    });

    // File upload handling
    function displaySelectedFiles(input) {
        const selectedFilesDiv = document.getElementById('selected-files');
        const fileListDiv = document.getElementById('file-list');

        if (input.files.length > 0) {
            if (input.files.length > 5) {
                alert('You can only upload up to 5 files at once.');
                input.value = '';
                return;
            }

            selectedFilesDiv.style.display = 'block';
            fileListDiv.innerHTML = '';

            Array.from(input.files).forEach((file, index) => {
                // Check file size (10MB limit)
                if (file.size > 10 * 1024 * 1024) {
                    alert(`File "${file.name}" is too large. Maximum size is 10MB.`);
                    input.value = '';
                    selectedFilesDiv.style.display = 'none';
                    return;
                }

                const fileItem = document.createElement('div');
                fileItem.className =
                    'flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-md text-sm';

                const fileInfo = document.createElement('div');
                fileInfo.className = 'flex items-center space-x-3';

                const fileIcon = getFileIcon(file.type);
                const fileName = document.createElement('span');
                fileName.className = 'text-gray-700 dark:text-gray-300 font-medium';
                fileName.textContent = file.name;

                const fileSize = document.createElement('span');
                fileSize.className = 'text-gray-500 dark:text-gray-400 text-xs';
                fileSize.textContent = formatFileSize(file.size);

                fileInfo.appendChild(fileIcon);
                fileInfo.appendChild(fileName);
                fileInfo.appendChild(fileSize);

                const removeButton = document.createElement('button');
                removeButton.type = 'button';
                removeButton.className =
                    'text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 p-1';
                removeButton.innerHTML =
                    '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>';
                removeButton.onclick = () => removeFile(index, input);

                fileItem.appendChild(fileInfo);
                fileItem.appendChild(removeButton);
                fileListDiv.appendChild(fileItem);
            });
        } else {
            selectedFilesDiv.style.display = 'none';
        }
    }

    function getFileIcon(fileType) {
        const icon = document.createElement('div');
        icon.className = 'w-8 h-8 rounded-md flex items-center justify-center text-xs font-medium text-white';

        if (fileType.includes('pdf')) {
            icon.className += ' bg-red-500';
            icon.textContent = 'PDF';
        } else if (fileType.includes('image')) {
            icon.className += ' bg-green-500';
            icon.textContent = 'IMG';
        } else if (fileType.includes('document') || fileType.includes('word')) {
            icon.className += ' bg-blue-500';
            icon.textContent = 'DOC';
        } else if (fileType.includes('sheet') || fileType.includes('excel')) {
            icon.className += ' bg-green-600';
            icon.textContent = 'XLS';
        } else if (fileType.includes('zip') || fileType.includes('rar')) {
            icon.className += ' bg-purple-500';
            icon.textContent = 'ZIP';
        } else {
            icon.className += ' bg-gray-500';
            icon.textContent = 'FILE';
        }

        return icon;
    }

    function removeFile(indexToRemove, input) {
        const dt = new DataTransfer();
        const files = Array.from(input.files);

        files.forEach((file, index) => {
            if (index !== indexToRemove) {
                dt.items.add(file);
            }
        });

        input.files = dt.files;
        displaySelectedFiles(input);
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Form validation
    document.getElementById('message-form').addEventListener('submit', function(e) {
        const submitBtn = document.getElementById('submit-btn');
        submitBtn.disabled = true;
        submitBtn.innerHTML =
            '<svg class="animate-spin w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Sending...';

        setTimeout(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML =
                '<svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>Send Message';
        }, 10000);
    });

    let autosaveTimer;
    const messageTextarea = document.getElementById('message');
    const subjectInput = document.getElementById('subject');

    function saveDraft() {
        const draftData = {
            subject: subjectInput.value,
            message: messageTextarea.value,
            type: document.getElementById('type').value,
            priority: document.getElementById('priority').value,
            project_id: document.getElementById('project_id')?.value || null
        };

        localStorage.setItem('message_draft', JSON.stringify(draftData));
    }

    function loadDraft() {
        const saved = localStorage.getItem('message_draft');
        if (saved) {
            try {
                const draftData = JSON.parse(saved);
                if (!subjectInput.value && draftData.subject) subjectInput.value = draftData.subject;
                if (!messageTextarea.value && draftData.message) messageTextarea.value = draftData.message;
                if (draftData.type) document.getElementById('type').value = draftData.type;
                if (draftData.priority) document.getElementById('priority').value = draftData.priority;
                if (draftData.project_id && document.getElementById('project_id')) {
                    document.getElementById('project_id').value = draftData.project_id;
                }
            } catch (e) {
                console.log('Error loading draft:', e);
            }
        }
    }

    [subjectInput, messageTextarea].forEach(element => {
        element.addEventListener('input', function() {
            clearTimeout(autosaveTimer);
            autosaveTimer = setTimeout(saveDraft, 2000);
        });
    });

    window.addEventListener('load', loadDraft);

    window.addEventListener('beforeunload', function() {
        if (document.querySelector('.alert-success')) {
            localStorage.removeItem('message_draft');
        }
    });
        document.addEventListener('DOMContentLoaded', function() {
            const tempFilesInput = document.getElementById('temp_files');
            const form = document.getElementById('message-form');
            let uploadedFiles = [];

            window.addEventListener('files-uploaded', function(event) {
                if (event.detail.component === 'message-attachments') {
                    if (event.detail.files) {
                        uploadedFiles.push(...event.detail.files);
                        updateTempFilesInput();
                    }
                }
            });

            window.addEventListener('file-deleted', function(event) {
                if (event.detail.component === 'message-attachments') {
                    uploadedFiles = uploadedFiles.filter(file => file.id !== event.detail.file.id);
                    updateTempFilesInput();
                }
            });

            function updateTempFilesInput() {
                const filePaths = uploadedFiles.map(file => file.path || file.file_path);
                tempFilesInput.value = JSON.stringify(filePaths);
            }

            // Form submission handling
            form.addEventListener('submit', function(e) {
                const submitBtn = document.getElementById('submit-btn');
                submitBtn.disabled = true;
                submitBtn.innerHTML = `
                    <svg class="animate-spin w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending...
                `;

                // Re-enable button after 10 seconds to prevent infinite disabled state
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = `
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                        </svg>
                        Send Message
                    `;
                }, 10000);
            });
        });
</script><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/client/messages/create.blade.php ENDPATH**/ ?>