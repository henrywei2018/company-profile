

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['message', 'showClient' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['message', 'showClient' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="flex flex-col">
    <div class="text-sm font-medium text-gray-900 dark:text-white">
        <?php echo e($message->subject); ?>

    </div>
    
    <?php if($showClient): ?>
    <div class="text-sm text-gray-500 dark:text-gray-400">
        <span class="font-medium"><?php echo e($message->name); ?></span>
        <?php if($message->user): ?>
            <span class="text-xs">(<?php echo e($message->user->email); ?>)</span>
        <?php else: ?>
            <span class="text-xs">(<?php echo e($message->email); ?>)</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <?php if($message->parent_id): ?>
        <div class="text-xs text-blue-600 dark:text-blue-400 mt-1">
            <?php if (isset($component)) { $__componentOriginald76ed9f25e575b539c5e0b3743018320 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald76ed9f25e575b539c5e0b3743018320 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.reply','data' => ['class' => 'w-3 h-3 inline mr-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.reply'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-3 h-3 inline mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald76ed9f25e575b539c5e0b3743018320)): ?>
<?php $attributes = $__attributesOriginald76ed9f25e575b539c5e0b3743018320; ?>
<?php unset($__attributesOriginald76ed9f25e575b539c5e0b3743018320); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald76ed9f25e575b539c5e0b3743018320)): ?>
<?php $component = $__componentOriginald76ed9f25e575b539c5e0b3743018320; ?>
<?php unset($__componentOriginald76ed9f25e575b539c5e0b3743018320); ?>
<?php endif; ?>
            Reply to conversation
        </div>
    <?php endif; ?>
</div><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/message-subject.blade.php ENDPATH**/ ?>