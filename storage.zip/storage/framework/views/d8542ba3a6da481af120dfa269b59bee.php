

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['message']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['message']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="flex flex-col ">
    
    <?php if(!$message->is_read): ?>
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
            <?php if (isset($component)) { $__componentOriginal923d5e4b42d51d513a43ad99f4733b48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal923d5e4b42d51d513a43ad99f4733b48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.mail','data' => ['class' => 'w-3 h-3 mr-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.mail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-3 h-3 mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal923d5e4b42d51d513a43ad99f4733b48)): ?>
<?php $attributes = $__attributesOriginal923d5e4b42d51d513a43ad99f4733b48; ?>
<?php unset($__attributesOriginal923d5e4b42d51d513a43ad99f4733b48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal923d5e4b42d51d513a43ad99f4733b48)): ?>
<?php $component = $__componentOriginal923d5e4b42d51d513a43ad99f4733b48; ?>
<?php unset($__componentOriginal923d5e4b42d51d513a43ad99f4733b48); ?>
<?php endif; ?>
            Unread
        </span>
    <?php else: ?>
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200">
            <?php if (isset($component)) { $__componentOriginalc84ddc28116d5d00406df4116b07f29b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc84ddc28116d5d00406df4116b07f29b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.mail-open','data' => ['class' => 'w-3 h-3 mr-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.mail-open'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-3 h-3 mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc84ddc28116d5d00406df4116b07f29b)): ?>
<?php $attributes = $__attributesOriginalc84ddc28116d5d00406df4116b07f29b; ?>
<?php unset($__attributesOriginalc84ddc28116d5d00406df4116b07f29b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc84ddc28116d5d00406df4116b07f29b)): ?>
<?php $component = $__componentOriginalc84ddc28116d5d00406df4116b07f29b; ?>
<?php unset($__componentOriginalc84ddc28116d5d00406df4116b07f29b); ?>
<?php endif; ?>
            Read
        </span>
    <?php endif; ?>
    
    
    <?php if(!$message->is_replied): ?>
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
            <?php if (isset($component)) { $__componentOriginal59e93c1c1ca50f33ed009c059d9798f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59e93c1c1ca50f33ed009c059d9798f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.clock','data' => ['class' => 'w-3 h-3 mr-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.clock'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-3 h-3 mr-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59e93c1c1ca50f33ed009c059d9798f4)): ?>
<?php $attributes = $__attributesOriginal59e93c1c1ca50f33ed009c059d9798f4; ?>
<?php unset($__attributesOriginal59e93c1c1ca50f33ed009c059d9798f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59e93c1c1ca50f33ed009c059d9798f4)): ?>
<?php $component = $__componentOriginal59e93c1c1ca50f33ed009c059d9798f4; ?>
<?php unset($__componentOriginal59e93c1c1ca50f33ed009c059d9798f4); ?>
<?php endif; ?>
            Pending
        </span>
    <?php endif; ?>
    
    
    <?php if($message->attachments->count() > 0): ?>
        <span class="text-gray-400" title="<?php echo e($message->attachments->count()); ?> attachment(s)">
            <?php if (isset($component)) { $__componentOriginald3556e169b64ae279e51bc1ff02f194e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3556e169b64ae279e51bc1ff02f194e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.paperclip','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.paperclip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3556e169b64ae279e51bc1ff02f194e)): ?>
<?php $attributes = $__attributesOriginald3556e169b64ae279e51bc1ff02f194e; ?>
<?php unset($__attributesOriginald3556e169b64ae279e51bc1ff02f194e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3556e169b64ae279e51bc1ff02f194e)): ?>
<?php $component = $__componentOriginald3556e169b64ae279e51bc1ff02f194e; ?>
<?php unset($__componentOriginald3556e169b64ae279e51bc1ff02f194e); ?>
<?php endif; ?>
        </span>
    <?php endif; ?>
</div><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/message-status.blade.php ENDPATH**/ ?>