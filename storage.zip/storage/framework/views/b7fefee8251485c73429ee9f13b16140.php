
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($mailMessage->subject ?? 'Notification'); ?></title>
    <style>
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 0;
        }
        .header {
            background-color: #3B82F6;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .content {
            padding: 30px;
        }
        .greeting {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #333;
        }
        .intro-line, .outro-line {
            margin: 15px 0;
            color: #555;
            line-height: 1.6;
        }
        .action-button {
            display: inline-block;
            background-color: #3B82F6;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px 0;
            font-weight: bold;
        }
        .action-button:hover {
            background-color: #2563EB;
        }
        .salutation {
            margin-top: 30px;
            color: #666;
            border-top: 1px solid #eee;
            padding-top: 20px;
        }
        .footer {
            background-color: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><?php echo e(config('app.name')); ?></h1>
        </div>
        
        <div class="content">
            <?php if($greeting): ?>
                <div class="greeting"><?php echo e($greeting); ?></div>
            <?php endif; ?>

            <?php if($introLines && count($introLines) > 0): ?>
                <?php $__currentLoopData = $introLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="intro-line"><?php echo e($line); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php if($actionText && $actionUrl): ?>
                <div style="text-align: center; margin: 30px 0;">
                    <a href="<?php echo e($actionUrl); ?>" class="action-button"><?php echo e($actionText); ?></a>
                </div>
            <?php endif; ?>

            <?php if($outroLines && count($outroLines) > 0): ?>
                <?php $__currentLoopData = $outroLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="outro-line"><?php echo e($line); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php if($salutation): ?>
                <div class="salutation"><?php echo $salutation; ?></div>
            <?php endif; ?>
        </div>

        <div class="footer">
            <p>
                This email was sent from <?php echo e(config('app.name')); ?>.<br>
                If you have any questions, please contact us at <?php echo e(config('mail.from.address')); ?>.
            </p>
        </div>
    </div>
</body>
</html><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/emails/notification.blade.php ENDPATH**/ ?>