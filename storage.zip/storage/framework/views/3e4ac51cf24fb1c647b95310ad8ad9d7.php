
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'formId' => 'bulk-form',
    'actionRoute',
    'actions' => [],
    'selectedCountText' => 'items selected'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'formId' => 'bulk-form',
    'actionRoute',
    'actions' => [],
    'selectedCountText' => 'items selected'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!-- Bulk Actions Form -->
<form id="<?php echo e($formId); ?>" method="POST" action="<?php echo e($actionRoute); ?>" class="hidden">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="action" id="bulk-action">
</form>

<!-- Bulk Actions Bar -->
<div id="bulk-actions" class="hidden mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
    <div class="flex items-center justify-between">
        <span id="selected-count" class="text-sm font-medium text-blue-900 dark:text-blue-100">
            0 <?php echo e($selectedCountText); ?>

        </span>
        <div class="flex gap-2">
            <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" 
                        onclick="bulkAction('<?php echo e($action['value']); ?>')" 
                        class="px-3 py-1 text-xs font-medium rounded-md hover:<?php echo e($action['hoverColor'] ?? 'bg-gray-200'); ?> <?php echo e($action['bgColor'] ?? 'bg-gray-100'); ?> <?php echo e($action['textColor'] ?? 'text-gray-700'); ?>">
                    <?php echo e($action['label']); ?>

                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Bulk selection functionality
    const selectAllCheckbox = document.getElementById('select-all');
    const itemCheckboxes = document.querySelectorAll('.item-checkbox');
    const bulkActions = document.getElementById('bulk-actions');
    const selectedCount = document.getElementById('selected-count');
    
    // Select all functionality
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            const isChecked = this.checked;
            itemCheckboxes.forEach(checkbox => {
                checkbox.checked = isChecked;
            });
            updateBulkActions();
        });
    }
    
    // Individual checkbox change
    itemCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
            if (selectAllCheckbox) {
                selectAllCheckbox.checked = checkedBoxes.length === itemCheckboxes.length;
                selectAllCheckbox.indeterminate = checkedBoxes.length > 0 && checkedBoxes.length < itemCheckboxes.length;
            }
            updateBulkActions();
        });
    });
    
    function updateBulkActions() {
        const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
        const count = checkedBoxes.length;
        
        if (count > 0) {
            bulkActions.classList.remove('hidden');
            selectedCount.textContent = `${count} <?php echo e($selectedCountText); ?>`;
        } else {
            bulkActions.classList.add('hidden');
        }
    }
});

// Bulk actions function
function bulkAction(action) {
    const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
    if (checkedBoxes.length === 0) {
        alert('Please select at least one item.');
        return;
    }

    const itemIds = Array.from(checkedBoxes).map(cb => cb.value);

    let confirmMessage = '';
    switch(action) {
        case 'delete':
            confirmMessage = `Are you sure you want to delete ${itemIds.length} item(s)?`;
            break;
        case 'activate':
            confirmMessage = `Are you sure you want to activate ${itemIds.length} item(s)?`;
            break;
        case 'deactivate':
            confirmMessage = `Are you sure you want to deactivate ${itemIds.length} item(s)?`;
            break;
        default:
            confirmMessage = `Are you sure you want to ${action} ${itemIds.length} item(s)?`;
    }

    if (!confirm(confirmMessage)) {
        return;
    }

    // Set action input
    document.getElementById('bulk-action').value = action;

    // Clear existing item_ids inputs
    const bulkForm = document.getElementById('<?php echo e($formId); ?>');
    const existingInputs = bulkForm.querySelectorAll('input[name*="_ids[]"]');
    existingInputs.forEach(el => el.remove());

    // Add fresh item_ids[] inputs
    const inputName = getInputName(action);
    itemIds.forEach(id => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = inputName;
        input.value = id;
        bulkForm.appendChild(input);
    });

    bulkForm.submit();
}

function getInputName(action) {
    // This can be customized based on your naming convention
    return 'item_ids[]'; // Default, can be overridden
}
</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/bulk-actions.blade.php ENDPATH**/ ?>