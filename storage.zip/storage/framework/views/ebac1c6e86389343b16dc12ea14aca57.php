

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'canForceDelete' => false,
    'showAssignActions' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'canForceDelete' => false,
    'showAssignActions' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="relative">
    <button type="button" id="more-actions-btn" onclick="toggleMoreActionsDropdown()"
            class="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
        More Actions
        <?php if (isset($component)) { $__componentOriginalc908c1599f75cbbe95349a183df29a7a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc908c1599f75cbbe95349a183df29a7a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.chevron-down','data' => ['class' => 'w-4 h-4 ml-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.chevron-down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 ml-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc908c1599f75cbbe95349a183df29a7a)): ?>
<?php $attributes = $__attributesOriginalc908c1599f75cbbe95349a183df29a7a; ?>
<?php unset($__attributesOriginalc908c1599f75cbbe95349a183df29a7a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc908c1599f75cbbe95349a183df29a7a)): ?>
<?php $component = $__componentOriginalc908c1599f75cbbe95349a183df29a7a; ?>
<?php unset($__componentOriginalc908c1599f75cbbe95349a183df29a7a); ?>
<?php endif; ?>
    </button>
    
    <div id="more-actions-dropdown" class="hidden absolute right-0 mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-50 border border-gray-200 dark:border-gray-700">
        <div class="py-1">
            <button type="button" onclick="bulkDelete()" 
                    class="w-full text-left px-4 py-2 text-sm text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20">
                <?php if (isset($component)) { $__componentOriginalf73b179a658b53da0d540ab0119a3553 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf73b179a658b53da0d540ab0119a3553 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.trash','data' => ['class' => 'w-4 h-4 inline mr-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.trash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 inline mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf73b179a658b53da0d540ab0119a3553)): ?>
<?php $attributes = $__attributesOriginalf73b179a658b53da0d540ab0119a3553; ?>
<?php unset($__attributesOriginalf73b179a658b53da0d540ab0119a3553); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf73b179a658b53da0d540ab0119a3553)): ?>
<?php $component = $__componentOriginalf73b179a658b53da0d540ab0119a3553; ?>
<?php unset($__componentOriginalf73b179a658b53da0d540ab0119a3553); ?>
<?php endif; ?>
                Delete Messages
            </button>
            
            <button type="button" onclick="bulkDeleteThreads()" 
                    class="w-full text-left px-4 py-2 text-sm text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20">
                <?php if (isset($component)) { $__componentOriginalf4cb3ccc0c20f35391248353691a6b69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf4cb3ccc0c20f35391248353691a6b69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.x-circle','data' => ['class' => 'w-4 h-4 inline mr-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.x-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 inline mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf4cb3ccc0c20f35391248353691a6b69)): ?>
<?php $attributes = $__attributesOriginalf4cb3ccc0c20f35391248353691a6b69; ?>
<?php unset($__attributesOriginalf4cb3ccc0c20f35391248353691a6b69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf4cb3ccc0c20f35391248353691a6b69)): ?>
<?php $component = $__componentOriginalf4cb3ccc0c20f35391248353691a6b69; ?>
<?php unset($__componentOriginalf4cb3ccc0c20f35391248353691a6b69); ?>
<?php endif; ?>
                Delete Conversations
            </button>
            
            <?php if($canForceDelete): ?>
                <button type="button" onclick="bulkForceDelete()" 
                        class="w-full text-left px-4 py-2 text-sm text-red-800 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 font-medium">
                    <?php if (isset($component)) { $__componentOriginal4a911ded7df28361b6ef1a9eae16ba33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a911ded7df28361b6ef1a9eae16ba33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.exclamation','data' => ['class' => 'w-4 h-4 inline mr-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.exclamation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 inline mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a911ded7df28361b6ef1a9eae16ba33)): ?>
<?php $attributes = $__attributesOriginal4a911ded7df28361b6ef1a9eae16ba33; ?>
<?php unset($__attributesOriginal4a911ded7df28361b6ef1a9eae16ba33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a911ded7df28361b6ef1a9eae16ba33)): ?>
<?php $component = $__componentOriginal4a911ded7df28361b6ef1a9eae16ba33; ?>
<?php unset($__componentOriginal4a911ded7df28361b6ef1a9eae16ba33); ?>
<?php endif; ?>
                    Force Delete
                </button>
            <?php endif; ?>
            
            <?php if($showAssignActions): ?>
                <div class="border-t border-gray-200 dark:border-gray-600"></div>
                <button type="button" onclick="showAssignDialog()" 
                        class="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                    <?php if (isset($component)) { $__componentOriginal47a1535ce80ff98c2e63d5c7c8b1f216 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal47a1535ce80ff98c2e63d5c7c8b1f216 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.user-group','data' => ['class' => 'w-4 h-4 inline mr-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.user-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 inline mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal47a1535ce80ff98c2e63d5c7c8b1f216)): ?>
<?php $attributes = $__attributesOriginal47a1535ce80ff98c2e63d5c7c8b1f216; ?>
<?php unset($__attributesOriginal47a1535ce80ff98c2e63d5c7c8b1f216); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal47a1535ce80ff98c2e63d5c7c8b1f216)): ?>
<?php $component = $__componentOriginal47a1535ce80ff98c2e63d5c7c8b1f216; ?>
<?php unset($__componentOriginal47a1535ce80ff98c2e63d5c7c8b1f216); ?>
<?php endif; ?>
                    Assign to Admin
                </button>
            <?php endif; ?>
            
            <div class="border-t border-gray-200 dark:border-gray-600"></div>
            <button type="button" onclick="previewBulkAction()" 
                    class="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                <?php if (isset($component)) { $__componentOriginal7e3dbfa36f71829ff09f371abf5a232c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e3dbfa36f71829ff09f371abf5a232c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.eye','data' => ['class' => 'w-4 h-4 inline mr-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.eye'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 inline mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e3dbfa36f71829ff09f371abf5a232c)): ?>
<?php $attributes = $__attributesOriginal7e3dbfa36f71829ff09f371abf5a232c; ?>
<?php unset($__attributesOriginal7e3dbfa36f71829ff09f371abf5a232c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e3dbfa36f71829ff09f371abf5a232c)): ?>
<?php $component = $__componentOriginal7e3dbfa36f71829ff09f371abf5a232c; ?>
<?php unset($__componentOriginal7e3dbfa36f71829ff09f371abf5a232c); ?>
<?php endif; ?>
                Preview Impact
            </button>
        </div>
    </div>
</div>

<script>
function toggleMoreActionsDropdown() {
    const dropdown = document.getElementById('more-actions-dropdown');
    dropdown.classList.toggle('hidden');
    
    // Close other dropdown
    document.getElementById('priority-dropdown')?.classList.add('hidden');
}

async function bulkForceDelete() {
    showConfirmationModal(
        'Force Delete Messages',
        `⚠️ WARNING: Force delete will permanently remove ${selectedMessages.size} message(s) and cannot be undone. This bypasses all safety checks.`,
        'delete',
        { force: true }
    );
}

function showAssignDialog() {
    // Implementation for showing assignment dialog
    // This would show a modal with admin selection
    alert('Assignment dialog would open here');
}

async function previewBulkAction() {
    if (selectedMessages.size === 0) {
        showNotification('Please select messages first.', 'warning');
        return;
    }
    
    try {
        const response = await fetch(bulkActionConfig.previewRoute, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json',
            },
            body: JSON.stringify({
                action: 'delete',
                message_ids: Array.from(selectedMessages)
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showImpactPreview(data.impact_info, data.message);
        } else {
            showNotification(data.message || 'Failed to preview action impact.', 'error');
        }
    } catch (error) {
        console.error('Preview error:', error);
        showNotification('An error occurred while previewing action impact.', 'error');
    }
}

function showImpactPreview(impactInfo, message) {
    const modal = document.getElementById('bulk-action-modal');
    const title = document.getElementById('modal-title');
    const messageEl = document.getElementById('modal-message');
    const impactPreview = document.getElementById('impact-preview');
    const impactDetails = document.getElementById('impact-details');
    const confirmBtn = document.getElementById('confirm-action-btn');
    
    title.textContent = 'Action Impact Preview';
    messageEl.textContent = message;
    
    // Show impact details
    impactDetails.innerHTML = `
        <div class="space-y-1">
            <div>Total messages: <strong>${impactInfo.total_messages}</strong></div>
            ${impactInfo.urgent_messages > 0 ? `<div class="text-red-600">Urgent messages: <strong>${impactInfo.urgent_messages}</strong></div>` : ''}
            ${impactInfo.project_linked > 0 ? `<div>Project-linked: <strong>${impactInfo.project_linked}</strong></div>` : ''}
            ${impactInfo.unique_clients > 0 ? `<div>Unique clients: <strong>${impactInfo.unique_clients}</strong></div>` : ''}
            ${impactInfo.with_attachments > 0 ? `<div>With attachments: <strong>${impactInfo.with_attachments}</strong></div>` : ''}
        </div>
    `;
    
    impactPreview.classList.remove('hidden');
    confirmBtn.textContent = 'Close';
    confirmBtn.className = 'px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-md hover:bg-gray-700';
    confirmBtn.onclick = closeModal;
    
    modal.classList.remove('hidden');
}
</script><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/bulk-actions/more-actions.blade.php ENDPATH**/ ?>