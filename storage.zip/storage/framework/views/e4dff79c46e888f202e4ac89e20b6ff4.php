

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'messages',
    'showBulkActions' => true,
    'showProjectColumn' => true,
    'showClientColumn' => true,
    'actionRoutes' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'messages',
    'showBulkActions' => true,
    'showProjectColumn' => true,
    'showClientColumn' => true,
    'actionRoutes' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white dark:bg-neutral-800 shadow-sm rounded-lg border border-gray-200 dark:border-gray-700">
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-50 dark:bg-gray-900">
                <tr>
                    <?php if($showBulkActions): ?>
                    
                    <th scope="col" class="px-6 py-3 text-left">
                        <input type="checkbox" id="select-all" 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    </th>
                    <?php endif; ?>
                    
                    
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Status
                    </th>
                    
                    
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Priority
                    </th>
                    
                    
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        <?php if($showClientColumn): ?> Client & <?php endif; ?> Subject
                    </th>
                    
                    
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Type
                    </th>
                    
                    <?php if($showProjectColumn): ?>
                    
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Project
                    </th>
                    <?php endif; ?>
                    
                    
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Date
                    </th>
                    
                    
                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody class="bg-white dark:bg-neutral-800 divide-y divide-gray-200 dark:divide-gray-700">
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 <?php echo e(!$message->is_read ? 'bg-blue-50 dark:bg-blue-900/20' : ''); ?>">
                        <?php if($showBulkActions): ?>
                        
                        <td class="px-6 py-4 whitespace-nowrap">
                            <input type="checkbox" name="message_ids[]" value="<?php echo e($message->id); ?>" 
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        </td>
                        <?php endif; ?>
                        
                        
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if (isset($component)) { $__componentOriginal38cec8a8f85a2c6d7654955823433a16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal38cec8a8f85a2c6d7654955823433a16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.message-status','data' => ['message' => $message]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.message-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal38cec8a8f85a2c6d7654955823433a16)): ?>
<?php $attributes = $__attributesOriginal38cec8a8f85a2c6d7654955823433a16; ?>
<?php unset($__attributesOriginal38cec8a8f85a2c6d7654955823433a16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal38cec8a8f85a2c6d7654955823433a16)): ?>
<?php $component = $__componentOriginal38cec8a8f85a2c6d7654955823433a16; ?>
<?php unset($__componentOriginal38cec8a8f85a2c6d7654955823433a16); ?>
<?php endif; ?>
                        </td>
                        
                        
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if (isset($component)) { $__componentOriginalca8e8ea67a126b23a7011f18b8645e9f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca8e8ea67a126b23a7011f18b8645e9f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.message-priority','data' => ['priority' => $message->priority]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.message-priority'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['priority' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message->priority)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca8e8ea67a126b23a7011f18b8645e9f)): ?>
<?php $attributes = $__attributesOriginalca8e8ea67a126b23a7011f18b8645e9f; ?>
<?php unset($__attributesOriginalca8e8ea67a126b23a7011f18b8645e9f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca8e8ea67a126b23a7011f18b8645e9f)): ?>
<?php $component = $__componentOriginalca8e8ea67a126b23a7011f18b8645e9f; ?>
<?php unset($__componentOriginalca8e8ea67a126b23a7011f18b8645e9f); ?>
<?php endif; ?>
                        </td>
                        
                        
                        <td class="px-6 py-4">
                            <?php if (isset($component)) { $__componentOriginalbfe9df9939afe73f6b4e67513d92b70c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfe9df9939afe73f6b4e67513d92b70c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.message-subject','data' => ['message' => $message,'showClient' => $showClientColumn]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.message-subject'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'showClient' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($showClientColumn)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfe9df9939afe73f6b4e67513d92b70c)): ?>
<?php $attributes = $__attributesOriginalbfe9df9939afe73f6b4e67513d92b70c; ?>
<?php unset($__attributesOriginalbfe9df9939afe73f6b4e67513d92b70c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfe9df9939afe73f6b4e67513d92b70c)): ?>
<?php $component = $__componentOriginalbfe9df9939afe73f6b4e67513d92b70c; ?>
<?php unset($__componentOriginalbfe9df9939afe73f6b4e67513d92b70c); ?>
<?php endif; ?>
                        </td>
                        
                        
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if (isset($component)) { $__componentOriginalffdae5aa6772e8242ff3b27f69d903fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffdae5aa6772e8242ff3b27f69d903fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.message-type','data' => ['type' => $message->type]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.message-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message->type)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffdae5aa6772e8242ff3b27f69d903fa)): ?>
<?php $attributes = $__attributesOriginalffdae5aa6772e8242ff3b27f69d903fa; ?>
<?php unset($__attributesOriginalffdae5aa6772e8242ff3b27f69d903fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffdae5aa6772e8242ff3b27f69d903fa)): ?>
<?php $component = $__componentOriginalffdae5aa6772e8242ff3b27f69d903fa; ?>
<?php unset($__componentOriginalffdae5aa6772e8242ff3b27f69d903fa); ?>
<?php endif; ?>
                        </td>
                        
                        <?php if($showProjectColumn): ?>
                        
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if (isset($component)) { $__componentOriginal8bbb165c8401b98e99ce9824fb62d2ff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8bbb165c8401b98e99ce9824fb62d2ff = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.message-project','data' => ['project' => $message->project]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.message-project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['project' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message->project)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8bbb165c8401b98e99ce9824fb62d2ff)): ?>
<?php $attributes = $__attributesOriginal8bbb165c8401b98e99ce9824fb62d2ff; ?>
<?php unset($__attributesOriginal8bbb165c8401b98e99ce9824fb62d2ff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bbb165c8401b98e99ce9824fb62d2ff)): ?>
<?php $component = $__componentOriginal8bbb165c8401b98e99ce9824fb62d2ff; ?>
<?php unset($__componentOriginal8bbb165c8401b98e99ce9824fb62d2ff); ?>
<?php endif; ?>
                        </td>
                        <?php endif; ?>
                        
                        
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            <?php if (isset($component)) { $__componentOriginal47e78db1b3d2896a2591265fcf1729d8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal47e78db1b3d2896a2591265fcf1729d8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.message-date','data' => ['date' => $message->created_at]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.message-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message->created_at)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal47e78db1b3d2896a2591265fcf1729d8)): ?>
<?php $attributes = $__attributesOriginal47e78db1b3d2896a2591265fcf1729d8; ?>
<?php unset($__attributesOriginal47e78db1b3d2896a2591265fcf1729d8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal47e78db1b3d2896a2591265fcf1729d8)): ?>
<?php $component = $__componentOriginal47e78db1b3d2896a2591265fcf1729d8; ?>
<?php unset($__componentOriginal47e78db1b3d2896a2591265fcf1729d8); ?>
<?php endif; ?>
                        </td>
                        
                        
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <?php if (isset($component)) { $__componentOriginal4c8e2f7040be1f36887b1c05ee41073a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c8e2f7040be1f36887b1c05ee41073a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.message-actions','data' => ['message' => $message,'routes' => $actionRoutes]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.message-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message),'routes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($actionRoutes)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c8e2f7040be1f36887b1c05ee41073a)): ?>
<?php $attributes = $__attributesOriginal4c8e2f7040be1f36887b1c05ee41073a; ?>
<?php unset($__attributesOriginal4c8e2f7040be1f36887b1c05ee41073a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c8e2f7040be1f36887b1c05ee41073a)): ?>
<?php $component = $__componentOriginal4c8e2f7040be1f36887b1c05ee41073a; ?>
<?php unset($__componentOriginal4c8e2f7040be1f36887b1c05ee41073a); ?>
<?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e($showBulkActions ? '8' : '7'); ?>" class="px-6 py-12 text-center text-gray-500 dark:text-gray-400">
                            <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['icon' => 'chat','title' => 'No messages found','description' => request()->hasAny(['search', 'status', 'priority']) ? 'No messages match your current filters.' : 'No messages have been received yet.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'chat','title' => 'No messages found','description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->hasAny(['search', 'status', 'priority']) ? 'No messages match your current filters.' : 'No messages have been received yet.')]); ?>
                                <?php if(request()->hasAny(['search', 'status', 'priority'])): ?>
                                    <a href="<?php echo e(route('admin.messages.index')); ?>" 
                                        class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
                                        Clear Filters
                                    </a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.messages.create')); ?>" 
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 shadow-sm">
                                    Send Message
                                </a>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    
    <?php if($messages->hasPages()): ?>
        <div class="px-6 py-3 border-t border-gray-200 dark:border-gray-700">
            <?php echo e($messages->links()); ?>

        </div>
    <?php endif; ?>
</div><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/messages-table.blade.php ENDPATH**/ ?>