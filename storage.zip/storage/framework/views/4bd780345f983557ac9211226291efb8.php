
<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Message Details','unreadMessages' => 0,'pendingApprovals' => 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Message Details','unreadMessages' => 0,'pendingApprovals' => 0]); ?>
    <div class="space-y-6">
        <!-- Page Header -->
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-3">
                        <li class="inline-flex items-center">
                            <a href="<?php echo e(route('admin.messages.index')); ?>"
                                class="text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400">
                                Messages
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd"
                                        d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                        clip-rule="evenodd"></path>
                                </svg>
                                <span class="ml-1 text-gray-500 dark:text-gray-400">Message Details</span>
                            </div>
                        </li>
                    </ol>
                </nav>
                <h1 class="mt-2 text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($rootMessage->subject); ?></h1>
            </div>

            <div class="mt-4 sm:mt-0 flex gap-3">
                <a href="<?php echo e(route('admin.messages.index')); ?>"
                    class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                    Back to Messages
                </a>

                <?php if($canReply): ?>
                    <a href="<?php echo e(route('admin.messages.reply', $rootMessage)); ?>"
                        class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"></path>
                        </svg>
                        Reply
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Message Thread -->
        <div class="grid grid-cols-1 xl:grid-cols-6 gap-6">
            <!-- Main Content - Conversation Thread -->
            <div class="xl:col-span-4 space-y-6">

                <!-- Thread Header -->
                <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('title', null, []); ?> 
                        <div class="flex items-center justify-between">
                            <span>Conversation (<?php echo e($thread->count()); ?> messages)</span>
                            <div class="flex items-center space-x-2">
                                <?php if($thread->where('is_read', false)->where('type', 'admin_to_client')->count() > 0): ?>
                                    <span
                                        class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">
                                        <?php echo e($thread->where('is_read', false)->where('type', 'admin_to_client')->count()); ?>

                                        unread
                                    </span>
                                <?php endif; ?>

                                <!-- Thread Priority Badge -->
                                <span
                                    class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium
                                    <?php echo e($rootMessage->priority === 'urgent'
                                        ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                                        : ($rootMessage->priority === 'high'
                                            ? 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'
                                            : ($rootMessage->priority === 'normal'
                                                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                                                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'))); ?>">
                                    <?php echo e(ucfirst($rootMessage->priority ?? 'normal')); ?>

                                </span>

                                <!-- Thread Type Badge -->
                                <span
                                    class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium
                                    <?php echo e($rootMessage->type === 'support'
                                        ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                                        : ($rootMessage->type === 'complaint'
                                            ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                                            : ($rootMessage->type === 'project_inquiry'
                                                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                                                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'))); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $rootMessage->type))); ?>

                                </span>
                            </div>
                        </div>
                     <?php $__env->endSlot(); ?>

                    <!-- Threaded Conversation Display -->
                    <div class="space-y-3" id="conversation-thread">
                        <?php $__currentLoopData = $thread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $threadMessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex <?php echo e($threadMessage->type === 'admin_to_client' ? 'flex-row-reverse' : ''); ?> gap-4"
                                data-message-id="<?php echo e($threadMessage->id); ?>">

                                <!-- Avatar -->
                                <div class="flex-shrink-0">
                                    <div
                                        class="w-10 h-10 rounded-full flex items-center justify-center
                                        <?php echo e($threadMessage->type === 'admin_to_client'
                                            ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400'
                                            : 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'); ?>">
                                        <?php if($threadMessage->type === 'admin_to_client'): ?>
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                                                </path>
                                            </svg>
                                        <?php else: ?>
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z">
                                                </path>
                                            </svg>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Message Content -->
                                <div class="flex-1 min-w-0">
                                    <div
                                        class="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3 <?php echo e($threadMessage->type === 'admin_to_client' ? 'border-l-4 border-green-400' : 'border-l-4 border-blue-400'); ?> break-words overflow-hidden">

                                        <!-- Message Header -->
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center gap-3 min-w-0 flex-1">
                                                <span
                                                    class="font-medium text-sm <?php echo e($threadMessage->type === 'admin_to_client' ? 'text-green-700 dark:text-green-400' : 'text-gray-900 dark:text-white'); ?>">
                                                    <?php echo e($threadMessage->type === 'admin_to_client' ? 'Admin Reply' : $threadMessage->name); ?>

                                                </span>
                                                <?php if($threadMessage->type !== 'admin_to_client'): ?>
                                                    <span
                                                        class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($threadMessage->email); ?></span>
                                                <?php endif; ?>
                                                <?php if(!$threadMessage->is_read && $threadMessage->type === 'admin_to_client'): ?>
                                                    <span
                                                        class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">
                                                        New
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="flex items-center gap-2">
                                                <span
                                                    class="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                                                    <?php echo e($threadMessage->created_at->format('M j, Y H:i')); ?>

                                                </span>
                                                <!-- Message Actions Dropdown -->
                                                <div class="relative" x-data="{ open: false }">
                                                    <button @click="open = !open"
                                                        class="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                            <path
                                                                d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z">
                                                            </path>
                                                        </svg>
                                                    </button>
                                                    <div x-show="open" @click.away="open = false" x-transition
                                                        class="absolute right-0 mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-gray-200 dark:border-gray-700">
                                                        <div class="py-1">
                                                            <?php if($threadMessage->type !== 'admin_to_client'): ?>
                                                                <a href="<?php echo e(route('admin.messages.reply', $threadMessage)); ?>"
                                                                    class="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                                                                    Reply to this message
                                                                </a>
                                                            <?php endif; ?>
                                                            <form
                                                                action="<?php echo e(route('admin.messages.toggle-read', $threadMessage)); ?>"
                                                                method="POST" class="block">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit"
                                                                    class="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                                                                    Mark as
                                                                    <?php echo e($threadMessage->is_read ? 'unread' : 'read'); ?>

                                                                </button>
                                                            </form>
                                                            <button onclick="copyMessageText(<?php echo e($threadMessage->id); ?>)"
                                                                class="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                                                                Copy message text
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <?php if($threadMessage->subject !== $rootMessage->subject): ?>
                                            <p class="text-sm font-semibold text-gray-800 dark:text-gray-200 mb-3">
                                                <?php echo e($threadMessage->subject); ?>

                                            </p>
                                        <?php endif; ?>

                                        <div class="text-sm text-gray-700 dark:text-gray-300 break-words overflow-wrap-anywhere"
                                            id="message-text-<?php echo e($threadMessage->id); ?>">
                                            <?php echo e($threadMessage->message); ?>

                                        </div>

                                        <?php if($threadMessage->attachments && $threadMessage->attachments->count() > 0): ?>
                                            <div class="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                                                <p class="text-xs text-gray-500 dark:text-gray-400 mb-3 font-medium">
                                                    Attachments (<?php echo e($threadMessage->attachments->count()); ?>):
                                                </p>
                                                <div class="flex flex-wrap gap-2">
                                                    <?php $__currentLoopData = $threadMessage->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('admin.messages.attachments.download', ['message' => $threadMessage->id, 'attachmentId' => $attachment->id])); ?>"
                                                            class="inline-flex items-center px-3 py-2 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-xs font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
                                                            <svg class="w-3 h-3 mr-2" fill="none"
                                                                stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    stroke-width="2"
                                                                    d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13">
                                                                </path>
                                                            </svg>
                                                            <?php echo e(\Illuminate\Support\Str::limit($attachment->file_name, 20)); ?>

                                                        </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>

                <!-- Quick Reply Form -->
                <?php if($canReply): ?>
    <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('title', null, []); ?> Quick Reply <?php $__env->endSlot(); ?>
        
        <form id="admin-reply-form" action="<?php echo e(route('admin.messages.reply', $rootMessage)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="space-y-4">
                <!-- Subject Field -->
                <div>
                    <label for="subject" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Subject <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="subject" id="subject" required
                           value="<?php echo e(old('subject', 'Re: ' . $rootMessage->subject)); ?>"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white"
                           placeholder="Reply subject">
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Message Content - ID FIXED ke 'message' -->
                <div>
                    <label for="message" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Your Reply <span class="text-red-500">*</span>
                    </label>
                    <textarea name="message" id="message" rows="6" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white"
                        placeholder="Type your reply here..."><?php echo e(old('message')); ?></textarea>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Universal File Uploader -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                        Attachments (Optional)
                    </label>
                    
                    <?php if (isset($component)) { $__componentOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.universal-file-uploader','data' => ['name' => 'files','multiple' => true,'maxFiles' => 5,'maxFileSize' => '10MB','acceptedFileTypes' => [
                            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
                            'application/pdf',
                            'application/msword',
                            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            'application/vnd.ms-excel',
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'text/plain', 'text/csv',
                            'application/zip',
                            'application/x-rar-compressed'
                        ],'dropDescription' => 'Drop files here or click to browse','uploadEndpoint' => ''.e(route('admin.messages.temp-upload')).'','deleteEndpoint' => ''.e(route('admin.messages.temp-delete')).'','enableCategories' => false,'enableDescription' => false,'enablePublicToggle' => false,'autoUpload' => true,'uploadOnDrop' => true,'compact' => false,'theme' => 'default','id' => 'admin-reply-attachments']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('universal-file-uploader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'files','multiple' => true,'maxFiles' => 5,'maxFileSize' => '10MB','acceptedFileTypes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'image/jpeg', 'image/png', 'image/gif', 'image/webp',
                            'application/pdf',
                            'application/msword',
                            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            'application/vnd.ms-excel',
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'text/plain', 'text/csv',
                            'application/zip',
                            'application/x-rar-compressed'
                        ]),'dropDescription' => 'Drop files here or click to browse','uploadEndpoint' => ''.e(route('admin.messages.temp-upload')).'','deleteEndpoint' => ''.e(route('admin.messages.temp-delete')).'','enableCategories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'enableDescription' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'enablePublicToggle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'autoUpload' => true,'uploadOnDrop' => true,'compact' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'theme' => 'default','id' => 'admin-reply-attachments']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93)): ?>
<?php $attributes = $__attributesOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93; ?>
<?php unset($__attributesOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93)): ?>
<?php $component = $__componentOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93; ?>
<?php unset($__componentOriginal5094ce7c6a61ba1cb6cef2c3f0c13f93); ?>
<?php endif; ?>
                    
                    <?php $__errorArgs = ['attachments.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- CRITICAL: Hidden input for temp files -->
                <input type="hidden" name="temp_files" id="temp_files" value="">

                <!-- Submit Button -->
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="clearReplyForm()" 
                            class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600">
                        Clear
                    </button>
                    <button type="submit" id="admin-reply-submit"
                            class="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md disabled:opacity-50">
                        Send Reply
                    </button>
                </div>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="xl:col-span-2 space-y-6">
                <!-- Message Actions -->
                <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('title', null, []); ?> Actions <?php $__env->endSlot(); ?>

                    <div class="space-y-3">
                        <?php if($canReply): ?>
                            <a href="<?php echo e(route('admin.messages.reply', $message)); ?>"
                                class="w-full inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 border border-transparent rounded-md text-sm font-medium text-white">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"></path>
                                </svg>
                                Reply via Email
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('admin.messages.index', ['search' => $message->email])); ?>"
                            class="w-full inline-flex items-center justify-center px-4 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                            </svg>
                            Search All Messages
                        </a>

                        <form action="<?php echo e(route('admin.messages.toggle-read', $message)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full inline-flex items-center justify-center px-4 py-2 bg-yellow-100 dark:bg-yellow-900/30 border border-yellow-200 dark:border-yellow-600 rounded-md text-sm font-medium text-yellow-700 dark:text-yellow-300 hover:bg-yellow-200 dark:hover:bg-yellow-900/50">
                                <?php if($message->is_read): ?>
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z">
                                        </path>
                                    </svg>
                                    Mark as Unread
                                <?php else: ?>
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    Mark as Read
                                <?php endif; ?>
                            </button>
                        </form>

                        <!-- Priority Actions -->
                        <div class="border-t border-gray-200 dark:border-gray-700 pt-3">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Update
                                Priority</label>
                            <form action="<?php echo e(route('admin.messages.update-priority', $message)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="flex space-x-2">
                                    <select name="priority"
                                        class="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white text-sm">
                                        <option value="low" <?php echo e($message->priority === 'low' ? 'selected' : ''); ?>>
                                            Low</option>
                                        <option value="normal"
                                            <?php echo e($message->priority === 'normal' ? 'selected' : ''); ?>>Normal</option>
                                        <option value="high" <?php echo e($message->priority === 'high' ? 'selected' : ''); ?>>
                                            High</option>
                                        <option value="urgent"
                                            <?php echo e($message->priority === 'urgent' ? 'selected' : ''); ?>>Urgent</option>
                                    </select>
                                    <button type="submit"
                                        class="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm">
                                        Update
                                    </button>
                                </div>
                            </form>
                        </div>

                        

                        <!-- Delete Message -->
                        <div class="border-t border-gray-200 dark:border-gray-700 pt-3">
                            <form action="<?php echo e(route('admin.messages.destroy', $message)); ?>" method="POST"
                                onsubmit="return confirm('Are you sure you want to delete this message? This action cannot be undone.')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="w-full inline-flex items-center justify-center px-4 py-2 bg-red-100 dark:bg-red-900/30 border border-red-200 dark:border-red-600 rounded-md text-sm font-medium text-red-700 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-900/50">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                        </path>
                                    </svg>
                                    Delete Message
                                </button>
                            </form>
                        </div>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>

                <!-- Message Information -->
                <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('title', null, []); ?> Message Information <?php $__env->endSlot(); ?>

                    <div class="space-y-3 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-500 dark:text-gray-400">Message ID:</span>
                            <span class="font-medium"><?php echo e($message->id); ?></span>
                        </div>

                        <div class="flex justify-between">
                            <span class="text-gray-500 dark:text-gray-400">Type:</span>
                            <span class="font-medium"><?php echo e(ucfirst(str_replace('_', ' ', $message->type))); ?></span>
                        </div>

                        <div class="flex justify-between">
                            <span class="text-gray-500 dark:text-gray-400">Priority:</span>
                            <span class="font-medium"><?php echo e(ucfirst($message->priority ?? 'normal')); ?></span>
                        </div>

                        <div class="flex justify-between">
                            <span class="text-gray-500 dark:text-gray-400">Status:</span>
                            <span
                                class="font-medium <?php echo e($message->is_read ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'); ?>">
                                <?php echo e($message->is_read ? 'Read' : 'Unread'); ?>

                            </span>
                        </div>

                        <div class="flex justify-between">
                            <span class="text-gray-500 dark:text-gray-400">Received:</span>
                            <span class="font-medium"><?php echo e($message->created_at->format('M j, Y H:i')); ?></span>
                        </div>

                        <?php if($message->updated_at && $message->updated_at != $message->created_at): ?>
                            <div class="flex justify-between">
                                <span class="text-gray-500 dark:text-gray-400">Last Updated:</span>
                                <span class="font-medium"><?php echo e($message->updated_at->format('M j, Y H:i')); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if($message->user): ?>
                            <div class="border-t border-gray-200 dark:border-gray-700 pt-3">
                                <div class="flex justify-between">
                                    <span class="text-gray-500 dark:text-gray-400">Client:</span>
                                    <a href="<?php echo e(route('admin.users.show', $message->user)); ?>"
                                        class="font-medium text-blue-600 dark:text-blue-400 hover:underline">
                                        <?php echo e($message->user->name); ?>

                                    </a>
                                </div>

                                <div class="flex justify-between mt-2">
                                    <span class="text-gray-500 dark:text-gray-400">Client Projects:</span>
                                    <span class="font-medium"><?php echo e($message->user->projects->count()); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($message->project): ?>
                            <div class="border-t border-gray-200 dark:border-gray-700 pt-3">
                                <div class="flex justify-between">
                                    <span class="text-gray-500 dark:text-gray-400">Related Project:</span>
                                    <a href="<?php echo e(route('admin.projects.show', $message->project)); ?>"
                                        class="font-medium text-blue-600 dark:text-blue-400 hover:underline">
                                        <?php echo e(Str::limit($message->project->title, 20)); ?>

                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($message->attachments && $message->attachments->count() > 0): ?>
                            <div class="border-t border-gray-200 dark:border-gray-700 pt-3">
                                <div class="flex justify-between">
                                    <span class="text-gray-500 dark:text-gray-400">Attachments:</span>
                                    <span class="font-medium"><?php echo e($message->attachments->count()); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>

                <!-- Client Information -->
                <?php if($clientInfo): ?>
                    <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('title', null, []); ?> Client Information <?php $__env->endSlot(); ?>

                        <div class="space-y-3 text-sm">
                            <div class="flex justify-between">
                                <span class="text-gray-500 dark:text-gray-400">Name:</span>
                                <span class="font-medium"><?php echo e($clientInfo['name']); ?></span>
                            </div>

                            <div class="flex justify-between">
                                <span class="text-gray-500 dark:text-gray-400">Email:</span>
                                <span class="font-medium"><?php echo e($clientInfo['email']); ?></span>
                            </div>

                            <?php if(isset($clientInfo['phone'])): ?>
                                <div class="flex justify-between">
                                    <span class="text-gray-500 dark:text-gray-400">Phone:</span>
                                    <span class="font-medium"><?php echo e($clientInfo['phone']); ?></span>
                                </div>
                            <?php endif; ?>

                            <?php if(isset($clientInfo['company'])): ?>
                                <div class="flex justify-between">
                                    <span class="text-gray-500 dark:text-gray-400">Company:</span>
                                    <span class="font-medium"><?php echo e($clientInfo['company']); ?></span>
                                </div>
                            <?php endif; ?>

                            <div class="flex justify-between">
                                <span class="text-gray-500 dark:text-gray-400">Total Messages:</span>
                                <span class="font-medium"><?php echo e($clientInfo['total_messages'] ?? 0); ?></span>
                            </div>

                            <div class="flex justify-between">
                                <span class="text-gray-500 dark:text-gray-400">Member Since:</span>
                                <span class="font-medium">
                                    <?php echo e(isset($clientInfo['member_since']) ? $clientInfo['member_since']->format('M Y') : 'N/A'); ?>

                                </span>
                            </div>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
                <?php endif; ?>

                <!-- Recent Activity -->
                <?php if(isset($recentActivity) && $recentActivity->count() > 0): ?>
                    <?php if (isset($component)) { $__componentOriginalad5130b5347ab6ecc017d2f5a278b926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('title', null, []); ?> Recent Activity <?php $__env->endSlot(); ?>

                        <div class="space-y-3">
                            <?php $__currentLoopData = $recentActivity->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="text-sm">
                                    <div class="flex items-start space-x-2">
                                        <div class="flex-shrink-0 w-2 h-2 bg-blue-400 rounded-full mt-1.5"></div>
                                        <div class="flex-1 min-w-0">
                                            <p class="text-gray-900 dark:text-white"><?php echo e($activity['description']); ?>

                                            </p>
                                            <p class="text-xs text-gray-500 dark:text-gray-400">
                                                <?php echo e($activity['created_at']->diffForHumans()); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $attributes = $__attributesOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__attributesOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926)): ?>
<?php $component = $__componentOriginalad5130b5347ab6ecc017d2f5a278b926; ?>
<?php unset($__componentOriginalad5130b5347ab6ecc017d2f5a278b926); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Forward Message Modal -->
    <div id="forward-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden"
        style="z-index: 50;">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white dark:bg-gray-800">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Forward Message</h3>

                <form id="forward-form" action="<?php echo e(route('admin.messages.forward', $message)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label for="forward_email"
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Forward to Email:
                        </label>
                        <input type="email" id="forward_email" name="email" required
                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                            placeholder="Enter email address">
                    </div>

                    <div class="mb-4">
                        <label for="forward_note"
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Additional Note (optional):
                        </label>
                        <textarea id="forward_note" name="note" rows="3"
                            class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                            placeholder="Add a note to include with the forwarded message..."></textarea>
                    </div>

                    <div class="flex justify-end space-x-3">
                        <button type="button" onclick="hideForwardModal()"
                            class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600">
                            Cancel
                        </button>
                        <button type="submit"
                            class="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md">
                            Forward Message
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script>
// FIXED: Admin Reply Universal Uploader Integration
let adminReplyUploadedFiles = []; // FIXED: variable name yang benar

document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Admin messages show view loaded with FIXED JavaScript');

    // Initialize all functionality
    initializeExistingFeatures();
    setupUniversalUploaderEvents();
    setupFormHandlers();
    handleSessionMessages();
});

// Initialize existing features
function initializeExistingFeatures() {
    // Character counter for message textarea - FIXED ID
    const messageTextarea = document.getElementById('message'); // FIXED: menggunakan ID yang benar
    if (messageTextarea) {
        updateCharCounter(messageTextarea);
        messageTextarea.addEventListener('input', function() {
            updateCharCounter(this);
        });
        console.log('✅ Message textarea found and initialized');
    } else {
        console.error('❌ Message textarea NOT found - check ID!');
    }

    // Auto-focus message area if needed
    if (messageTextarea && !messageTextarea.value.trim()) {
        setTimeout(() => messageTextarea.focus(), 500);
    }
}

// FIXED: Universal Uploader event listeners
function setupUniversalUploaderEvents() {
    console.log('🔧 Setting up FIXED universal uploader events...');

    // Listen for file uploads - FIXED event handler
    window.addEventListener('files-uploaded', function(e) {
        console.log('🎯 Files uploaded event captured:', e.detail);
        
        // Check if this is for our admin uploader
        if (isEventForAdminReplyUploader(e.detail)) {
            console.log('✅ Event is for admin reply uploader');
            
            if (e.detail.files && Array.isArray(e.detail.files)) {
                const newFilePaths = e.detail.files.map(file => extractFilePath(file)).filter(path => path);
                
                if (newFilePaths.length > 0) {
                    // FIXED: Prevent duplicates from the start
                    const uniqueNewFiles = newFilePaths.filter(path => !adminReplyUploadedFiles.includes(path));
                    
                    if (uniqueNewFiles.length > 0) {
                        adminReplyUploadedFiles = [...adminReplyUploadedFiles, ...uniqueNewFiles];
                        updateTempFilesInput();
                        console.log('✅ New unique files added:', uniqueNewFiles);
                        console.log('📁 Total files now:', adminReplyUploadedFiles.length);
                    } else {
                        console.log('ℹ️ No new files to add (all were duplicates)');
                    }
                }
            }
        }
    });

    // Listen for single file uploads
    window.addEventListener('file-uploaded', function(e) {
        console.log('📎 Single file uploaded:', e.detail);
        
        if (isEventForAdminReplyUploader(e.detail)) {
            const filePath = extractFilePath(e.detail);
            if (filePath && !adminReplyUploadedFiles.includes(filePath)) {
                adminReplyUploadedFiles.push(filePath);
                updateTempFilesInput();
                console.log('✅ Single file added:', filePath);
            }
        }
    });

    // Listen for file deletions
    window.addEventListener('file-deleted', function(e) {
        console.log('🗑️ File deleted:', e.detail);
        
        if (isEventForAdminReplyUploader(e.detail)) {
            const filePathToRemove = extractFilePath(e.detail);
            if (filePathToRemove) {
                adminReplyUploadedFiles = adminReplyUploadedFiles.filter(path => path !== filePathToRemove);
                updateTempFilesInput();
                console.log('🗑️ File removed:', filePathToRemove);
                console.log('📁 Remaining files:', adminReplyUploadedFiles.length);
            }
        }
    });
}

// Check if event is for our admin reply uploader - FIXED
function isEventForAdminReplyUploader(eventDetail) {
    const uploaderIds = ['admin-reply-attachments', 'message-attachments', 'reply-attachments'];
    
    // Check by uploader ID
    if (eventDetail.uploaderId && uploaderIds.includes(eventDetail.uploaderId)) {
        return true;
    }
    
    // Check by element ID
    if (eventDetail.elementId && uploaderIds.includes(eventDetail.elementId)) {
        return true;
    }
    
    // Check by target element
    if (eventDetail.target && eventDetail.target.id && uploaderIds.includes(eventDetail.target.id)) {
        return true;
    }
    
    // Fallback: admin messages page
    return window.location.pathname.includes('/admin/messages/');
}

// Extract file path from event data
function extractFilePath(eventData) {
    if (typeof eventData === 'string') {
        return eventData;
    }
    
    if (eventData && typeof eventData === 'object') {
        return eventData.path || 
               eventData.file_path || 
               eventData.filePath || 
               eventData.url || 
               eventData.file?.path ||
               eventData.file?.file_path ||
               null;
    }
    
    return null;
}

// FIXED: Update temp_files input with duplicate prevention
function updateTempFilesInput() {
    // Remove duplicates
    adminReplyUploadedFiles = [...new Set(adminReplyUploadedFiles)];
    
    const tempFilesInput = document.getElementById('temp_files');
    if (tempFilesInput) {
        const filesJson = JSON.stringify(adminReplyUploadedFiles);
        tempFilesInput.value = filesJson;
        console.log('📝 Updated temp_files input (duplicates removed):', filesJson);
        console.log('📊 Total unique files:', adminReplyUploadedFiles.length);
    } else {
        console.error('❌ temp_files input not found!');
    }
}

// FIXED: Form submission handler
function setupFormHandlers() {
    const replyForm = document.getElementById('admin-reply-form'); // FIXED: menggunakan ID yang tepat
    if (replyForm) {
        console.log('✅ Admin reply form found and initialized');
        
        replyForm.addEventListener('submit', function(e) {
            console.log('📤 Admin reply form submitting...');
            console.log('📁 Files being submitted:', adminReplyUploadedFiles);
            console.log('📝 temp_files input value:', document.getElementById('temp_files')?.value);
            
            // Optional: Add form validation
            const messageText = document.getElementById('message')?.value?.trim();
            if (!messageText) {
                e.preventDefault();
                showNotification('Please enter a reply message', 'error');
                return false;
            }
            
            // Disable submit button to prevent double submission
            const submitBtn = document.getElementById('admin-reply-submit');
            if (submitBtn) {
                submitBtn.disabled = true;
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '⏳ Sending...';
                
                // Re-enable after timeout
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }, 15000);
            }
        });
    } else {
        console.error('❌ Admin reply form NOT found - check form ID!');
    }
}

// Character counter functionality
function updateCharCounter(textarea) {
    const charCount = textarea.value.length;
    const maxLength = 10000;
    
    let counterElement = document.getElementById('char-count');
    if (!counterElement) {
        counterElement = document.createElement('div');
        counterElement.id = 'char-count';
        counterElement.className = 'text-sm text-gray-500 mt-1';
        textarea.parentNode.appendChild(counterElement);
    }
    
    counterElement.textContent = `${charCount}/${maxLength} characters`;
    
    if (charCount > maxLength * 0.9) {
        counterElement.className = 'text-sm text-red-500 mt-1';
    } else {
        counterElement.className = 'text-sm text-gray-500 mt-1';
    }
}

// Handle Laravel session messages
function handleSessionMessages() {
    <?php if(session('success')): ?>
        showNotification('<?php echo e(session("success")); ?>', 'success');
        clearFormAfterSuccess();
    <?php endif; ?>

    <?php if(session('error')): ?>
        showNotification('<?php echo e(session("error")); ?>', 'error');
    <?php endif; ?>

    <?php if(session('warning')): ?>
        showNotification('<?php echo e(session("warning")); ?>', 'warning');
    <?php endif; ?>
}

// Clear form after successful submission
function clearFormAfterSuccess() {
    const messageTextarea = document.getElementById('message');
    const subjectInput = document.getElementById('subject');
    const tempFilesInput = document.getElementById('temp_files');
    
    if (messageTextarea) messageTextarea.value = '';
    if (subjectInput) subjectInput.value = 'Re: <?php echo e($rootMessage->subject ?? ""); ?>';
    if (tempFilesInput) tempFilesInput.value = '';
    
    adminReplyUploadedFiles = [];
    clearUploaderInstances();
    
    console.log('✅ Admin reply form cleared after successful submission');
}

// Clear uploader instances
function clearUploaderInstances() {
    const uploaderIds = ['admin-reply-attachments', 'message-attachments', 'reply-attachments'];
    
    if (window.universalUploaderInstances) {
        uploaderIds.forEach(uploaderId => {
            if (window.universalUploaderInstances[uploaderId]) {
                try {
                    window.universalUploaderInstances[uploaderId].clearAll();
                    console.log(`🧹 Cleared uploader instance: ${uploaderId}`);
                } catch (e) {
                    console.warn(`⚠️ Failed to clear ${uploaderId}:`, e);
                }
            }
        });
    }
    
    // Also try Vue instances
    const uploaderElements = uploaderIds.map(id => document.getElementById(id)).filter(el => el);
    
    uploaderElements.forEach(element => {
        if (element && element.__vue__ && element.__vue__.clearAll) {
            try {
                element.__vue__.clearAll();
                console.log(`🧹 Cleared Vue instance on ${element.id}`);
            } catch (e) {
                console.warn(`⚠️ Failed to clear Vue instance on ${element.id}:`, e);
            }
        }
    });
}

// Clear reply form manually
function clearReplyForm() {
    if (confirm('Are you sure you want to clear this form?')) {
        clearFormAfterSuccess();
        showNotification('Form cleared', 'success');
    }
}

// Show notification function
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-md shadow-lg max-w-sm ${
        type === 'success' ? 'bg-green-100 text-green-800 border border-green-200' :
        type === 'error' ? 'bg-red-100 text-red-800 border border-red-200' :
        type === 'warning' ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' :
        'bg-blue-100 text-blue-800 border border-blue-200'
    }`;
    
    notification.innerHTML = `
        <div class="flex items-center">
            <div class="flex-1">${message}</div>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-2 text-current hover:opacity-70">
                ×
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// FIXED: Debug function
window.debugAdminReplyUploader = function() {
    console.log('🐛 FIXED Admin Reply Uploader Debug Info:');
    console.log('=====================================');
    console.log('📁 Current files array:', adminReplyUploadedFiles);
    console.log('📝 temp_files input element:', document.getElementById('temp_files'));
    console.log('📝 temp_files input value:', document.getElementById('temp_files')?.value);
    console.log('🔧 Universal uploader instances:', window.universalUploaderInstances);
    console.log('📂 DOM elements:', {
        form: document.getElementById('admin-reply-form'),
        messageTextarea: document.getElementById('message'),
        subjectInput: document.getElementById('subject'),
        tempFilesInput: document.getElementById('temp_files'),
        uploaderElement: document.getElementById('admin-reply-attachments'),
        submitButton: document.getElementById('admin-reply-submit')
    });
    console.log('=====================================');
};

// Clear duplicates function
window.clearDuplicateFiles = function() {
    const originalCount = adminReplyUploadedFiles.length;
    adminReplyUploadedFiles = [...new Set(adminReplyUploadedFiles)];
    updateTempFilesInput();
    console.log(`🧹 Removed ${originalCount - adminReplyUploadedFiles.length} duplicate files`);
    console.log('📁 Unique files remaining:', adminReplyUploadedFiles);
};

// Export functions to global scope
window.clearReplyForm = clearReplyForm;
window.showNotification = showNotification;

console.log('✅ FIXED JavaScript loaded - try: debugAdminReplyUploader()');
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/admin/messages/show.blade.php ENDPATH**/ ?>