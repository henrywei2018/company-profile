

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['message', 'routes' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['message', 'routes' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="flex items-center justify-end space-x-2">
    
    <?php if(isset($routes['show'])): ?>
    <a href="<?php echo e(route($routes['show'], $message)); ?>" 
       class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300" 
       title="View Message">
        <?php if (isset($component)) { $__componentOriginal7e3dbfa36f71829ff09f371abf5a232c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e3dbfa36f71829ff09f371abf5a232c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.eye','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.eye'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e3dbfa36f71829ff09f371abf5a232c)): ?>
<?php $attributes = $__attributesOriginal7e3dbfa36f71829ff09f371abf5a232c; ?>
<?php unset($__attributesOriginal7e3dbfa36f71829ff09f371abf5a232c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e3dbfa36f71829ff09f371abf5a232c)): ?>
<?php $component = $__componentOriginal7e3dbfa36f71829ff09f371abf5a232c; ?>
<?php unset($__componentOriginal7e3dbfa36f71829ff09f371abf5a232c); ?>
<?php endif; ?>
    </a>
    <?php endif; ?>
    
    
    <?php if(isset($routes['reply'])): ?>
    <a href="<?php echo e(route($routes['reply'], $message)); ?>" 
       class="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300" 
       title="Reply">
        <?php if (isset($component)) { $__componentOriginald76ed9f25e575b539c5e0b3743018320 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald76ed9f25e575b539c5e0b3743018320 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.reply','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.reply'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald76ed9f25e575b539c5e0b3743018320)): ?>
<?php $attributes = $__attributesOriginald76ed9f25e575b539c5e0b3743018320; ?>
<?php unset($__attributesOriginald76ed9f25e575b539c5e0b3743018320); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald76ed9f25e575b539c5e0b3743018320)): ?>
<?php $component = $__componentOriginald76ed9f25e575b539c5e0b3743018320; ?>
<?php unset($__componentOriginald76ed9f25e575b539c5e0b3743018320); ?>
<?php endif; ?>
    </a>
    <?php endif; ?>
    
    
    <?php if(isset($routes['toggle_read'])): ?>
    <form action="<?php echo e(route($routes['toggle_read'], $message)); ?>" method="POST" class="inline">
        <?php echo csrf_field(); ?>
        <button type="submit" 
                class="text-yellow-600 hover:text-yellow-900 dark:text-yellow-400 dark:hover:text-yellow-300" 
                title="<?php echo e($message->is_read ? 'Mark as Unread' : 'Mark as Read'); ?>">
            <?php if($message->is_read): ?>
                <?php if (isset($component)) { $__componentOriginal923d5e4b42d51d513a43ad99f4733b48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal923d5e4b42d51d513a43ad99f4733b48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.mail','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.mail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal923d5e4b42d51d513a43ad99f4733b48)): ?>
<?php $attributes = $__attributesOriginal923d5e4b42d51d513a43ad99f4733b48; ?>
<?php unset($__attributesOriginal923d5e4b42d51d513a43ad99f4733b48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal923d5e4b42d51d513a43ad99f4733b48)): ?>
<?php $component = $__componentOriginal923d5e4b42d51d513a43ad99f4733b48; ?>
<?php unset($__componentOriginal923d5e4b42d51d513a43ad99f4733b48); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginalc84ddc28116d5d00406df4116b07f29b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc84ddc28116d5d00406df4116b07f29b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.mail-open','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.mail-open'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc84ddc28116d5d00406df4116b07f29b)): ?>
<?php $attributes = $__attributesOriginalc84ddc28116d5d00406df4116b07f29b; ?>
<?php unset($__attributesOriginalc84ddc28116d5d00406df4116b07f29b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc84ddc28116d5d00406df4116b07f29b)): ?>
<?php $component = $__componentOriginalc84ddc28116d5d00406df4116b07f29b; ?>
<?php unset($__componentOriginalc84ddc28116d5d00406df4116b07f29b); ?>
<?php endif; ?>
            <?php endif; ?>
        </button>
    </form>
    <?php endif; ?>
    
    
    <?php if(isset($routes['destroy'])): ?>
    <form action="<?php echo e(route($routes['destroy'], $message)); ?>" method="POST" class="inline" 
          onsubmit="return confirm('Are you sure you want to delete this message?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" 
                class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300" 
                title="Delete Message">
            <?php if (isset($component)) { $__componentOriginalf73b179a658b53da0d540ab0119a3553 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf73b179a658b53da0d540ab0119a3553 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icons.trash','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icons.trash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf73b179a658b53da0d540ab0119a3553)): ?>
<?php $attributes = $__attributesOriginalf73b179a658b53da0d540ab0119a3553; ?>
<?php unset($__attributesOriginalf73b179a658b53da0d540ab0119a3553); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf73b179a658b53da0d540ab0119a3553)): ?>
<?php $component = $__componentOriginalf73b179a658b53da0d540ab0119a3553; ?>
<?php unset($__componentOriginalf73b179a658b53da0d540ab0119a3553); ?>
<?php endif; ?>
        </button>
    </form>
    <?php endif; ?>
</div><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/message-actions.blade.php ENDPATH**/ ?>