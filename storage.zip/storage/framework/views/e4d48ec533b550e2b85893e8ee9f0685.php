
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Dashboard',
    'enableCharts' => false,
    'unreadMessages' => 0,
    'pendingApprovals' => 0,
    'recentNotifications' => null,
    'unreadNotificationsCount' => 0,
    'unreadMessagesCount' => 0,
    'pendingApprovalsCount' => 0,
    'overdueProjectsCount' => 0
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Dashboard',
    'enableCharts' => false,
    'unreadMessages' => 0,
    'pendingApprovals' => 0,
    'recentNotifications' => null,
    'unreadNotificationsCount' => 0,
    'unreadMessagesCount' => 0,
    'pendingApprovalsCount' => 0,
    'overdueProjectsCount' => 0
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php if(auth()->guard()->check()): ?>
        <meta name="auth-user-id" content="<?php echo e(auth()->id()); ?>">
        <meta name="is-admin" content="<?php echo e(auth()->user()->hasRole(['admin', 'super-admin']) ? 'true' : 'false'); ?>">
    <?php endif; ?>

    <title><?php echo e($title); ?> - Client Panel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-VYHSLQXJE5"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-VYHSLQXJE5');
    </script>
    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Custom Styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>

    <!-- Initial theme check -->
    <script>
        // Quick theme check before page load to prevent flashing
        const html = document.querySelector('html');
        const isLightOrAuto = localStorage.getItem('hs_theme') === 'light' || (localStorage.getItem('hs_theme') ===
            'auto' && !window.matchMedia('(prefers-color-scheme: dark)').matches);
        const isDarkOrAuto = localStorage.getItem('hs_theme') === 'dark' || (localStorage.getItem('hs_theme') === 'auto' &&
            window.matchMedia('(prefers-color-scheme: dark)').matches);

        if (isLightOrAuto && html.classList.contains('dark')) html.classList.remove('dark');
        else if (isDarkOrAuto && html.classList.contains('light')) html.classList.remove('light');
        else if (isDarkOrAuto && !html.classList.contains('dark')) html.classList.add('dark');
        else if (isLightOrAuto && !html.classList.contains('light')) html.classList.add('light');
    </script>

    <?php if($enableCharts): ?>
        <!-- Apexcharts -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/apexcharts/dist/apexcharts.css">
        <style type="text/css">
            .apexcharts-tooltip.apexcharts-theme-light {
                background-color: transparent !important;
                border: none !important;
                box-shadow: none !important;
            }
        </style>
    <?php endif; ?>
</head>

<body class="bg-gray-50 dark:bg-neutral-900">
    <!-- ========== HEADER ========== -->
    <?php if (isset($component)) { $__componentOriginal0cb7e04ed12e86455aa04643cef71c19 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0cb7e04ed12e86455aa04643cef71c19 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client.client-header','data' => ['unreadMessagesCount' => $unreadMessagesCount ?? $unreadMessages ?? 0,'pendingQuotationsCount' => $pendingApprovalsCount ?? $pendingApprovals ?? 0,'recentNotifications' => $recentNotifications ?? collect(),'unreadNotificationsCount' => $unreadNotificationsCount ?? 0,'pendingApprovalsCount' => $pendingApprovalsCount ?? $pendingApprovals ?? 0,'overdueProjectsCount' => $overdueProjectsCount ?? 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client.client-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['unreadMessagesCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($unreadMessagesCount ?? $unreadMessages ?? 0),'pendingQuotationsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingApprovalsCount ?? $pendingApprovals ?? 0),'recentNotifications' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentNotifications ?? collect()),'unreadNotificationsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($unreadNotificationsCount ?? 0),'pendingApprovalsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingApprovalsCount ?? $pendingApprovals ?? 0),'overdueProjectsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($overdueProjectsCount ?? 0)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0cb7e04ed12e86455aa04643cef71c19)): ?>
<?php $attributes = $__attributesOriginal0cb7e04ed12e86455aa04643cef71c19; ?>
<?php unset($__attributesOriginal0cb7e04ed12e86455aa04643cef71c19); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0cb7e04ed12e86455aa04643cef71c19)): ?>
<?php $component = $__componentOriginal0cb7e04ed12e86455aa04643cef71c19; ?>
<?php unset($__componentOriginal0cb7e04ed12e86455aa04643cef71c19); ?>
<?php endif; ?>
    <!-- ========== END HEADER ========== -->

    <!-- ========== MAIN CONTENT ========== -->
    <!-- Mobile breadcrumb -->
    <?php if (isset($component)) { $__componentOriginalbc77d21e7eeac60d6f40f816afb7b0f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc77d21e7eeac60d6f40f816afb7b0f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.breadcrumb-mobile','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.breadcrumb-mobile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc77d21e7eeac60d6f40f816afb7b0f2)): ?>
<?php $attributes = $__attributesOriginalbc77d21e7eeac60d6f40f816afb7b0f2; ?>
<?php unset($__attributesOriginalbc77d21e7eeac60d6f40f816afb7b0f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc77d21e7eeac60d6f40f816afb7b0f2)): ?>
<?php $component = $__componentOriginalbc77d21e7eeac60d6f40f816afb7b0f2; ?>
<?php unset($__componentOriginalbc77d21e7eeac60d6f40f816afb7b0f2); ?>
<?php endif; ?>

    <!-- Sidebar -->
    <?php if (isset($component)) { $__componentOriginalcb184c73ff0a9bda2c48d35cc6dd8fc7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb184c73ff0a9bda2c48d35cc6dd8fc7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client.client-sidebar','data' => ['unreadMessagesCount' => $unreadMessages,'pendingApprovalsCount' => $pendingApprovals]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client.client-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['unreadMessagesCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($unreadMessages),'pendingApprovalsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pendingApprovals)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb184c73ff0a9bda2c48d35cc6dd8fc7)): ?>
<?php $attributes = $__attributesOriginalcb184c73ff0a9bda2c48d35cc6dd8fc7; ?>
<?php unset($__attributesOriginalcb184c73ff0a9bda2c48d35cc6dd8fc7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb184c73ff0a9bda2c48d35cc6dd8fc7)): ?>
<?php $component = $__componentOriginalcb184c73ff0a9bda2c48d35cc6dd8fc7; ?>
<?php unset($__componentOriginalcb184c73ff0a9bda2c48d35cc6dd8fc7); ?>
<?php endif; ?>

    <!-- Content -->
    <div class="w-full lg:ps-64">
        <div class="p-4 sm:p-6 space-y-4 sm:space-y-6">
            <!-- Flash Messages -->
            <?php if(session('success')): ?>
                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'success','class' => 'mb-4','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success','class' => 'mb-4','dismissible' => true]); ?>
                    <?php echo e(session('success')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'error','class' => 'mb-4','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error','class' => 'mb-4','dismissible' => true]); ?>
                    <?php echo e(session('error')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
            <?php endif; ?>

            <?php if(session('info')): ?>
                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'info','class' => 'mb-4','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'info','class' => 'mb-4','dismissible' => true]); ?>
                    <?php echo e(session('info')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
            <?php endif; ?>

            <?php if(session('warning')): ?>
                <?php if (isset($component)) { $__componentOriginald888329b8246e32afd68d2decbd25cf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald888329b8246e32afd68d2decbd25cf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.alert','data' => ['type' => 'warning','class' => 'mb-4','dismissible' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning','class' => 'mb-4','dismissible' => true]); ?>
                    <?php echo e(session('warning')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $attributes = $__attributesOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__attributesOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald888329b8246e32afd68d2decbd25cf1)): ?>
<?php $component = $__componentOriginald888329b8246e32afd68d2decbd25cf1; ?>
<?php unset($__componentOriginald888329b8246e32afd68d2decbd25cf1); ?>
<?php endif; ?>
            <?php endif; ?>

            <!-- Page Content -->
            <?php echo e($slot); ?>

        </div>
    </div>
    <!-- Chat Widget -->
    <?php if (isset($component)) { $__componentOriginal2f2d6d240d8b5bb0ae740a50d4cd2158 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f2d6d240d8b5bb0ae740a50d4cd2158 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chat-widget','data' => ['size' => 'compact','theme' => 'client','autoOpen' => false,'showOnlineStatus' => true,'welcomeMessage' => 'Halo! Ada yang bisa kami bantu?','operatorName' => 'Customer Support']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chat-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'compact','theme' => 'client','auto-open' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'show-online-status' => true,'welcome-message' => 'Halo! Ada yang bisa kami bantu?','operator-name' => 'Customer Support']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f2d6d240d8b5bb0ae740a50d4cd2158)): ?>
<?php $attributes = $__attributesOriginal2f2d6d240d8b5bb0ae740a50d4cd2158; ?>
<?php unset($__attributesOriginal2f2d6d240d8b5bb0ae740a50d4cd2158); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f2d6d240d8b5bb0ae740a50d4cd2158)): ?>
<?php $component = $__componentOriginal2f2d6d240d8b5bb0ae740a50d4cd2158; ?>
<?php unset($__componentOriginal2f2d6d240d8b5bb0ae740a50d4cd2158); ?>
<?php endif; ?>
    
    <!-- ========== END MAIN CONTENT ========== -->
<script>
        // Hide loading screen when page is ready
        document.addEventListener('DOMContentLoaded', function() {
            const loadingScreen = document.getElementById('loading-screen');
            if (loadingScreen) {
                loadingScreen.style.display = 'none';
            }
        });

        // Global error handler
        window.addEventListener('error', function(e) {
            console.error('Global error:', e.error);
        });

        // Global unhandled promise rejection handler
        window.addEventListener('unhandledrejection', function(e) {
            console.error('Unhandled promise rejection:', e.reason);
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/layouts/client.blade.php ENDPATH**/ ?>