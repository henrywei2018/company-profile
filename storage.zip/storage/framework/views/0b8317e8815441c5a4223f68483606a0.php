<!-- resources/views/components/admin/card.blade.php -->
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
    'subtitle' => null,
    'footer' => null,
    'headerActions' => null,
    'noPadding' => false,
    'bodyClass' => ''
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
    'subtitle' => null,
    'footer' => null,
    'headerActions' => null,
    'noPadding' => false,
    'bodyClass' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => 'bg-white border border-gray-200 rounded-xl shadow-sm dark:bg-neutral-800 dark:border-neutral-700'])); ?>>
    <?php if($title || $subtitle || $headerActions): ?>
    <div class="px-2 py-1 border-gray-200 dark:border-neutral-700 flex flex-wrap justify-between items-center gap-3">
        <div>
            <?php if($title): ?>
            <h3 class="text-lg font-medium text-gray-900 dark:text-white">
                <?php echo e($title); ?>

            </h3>
            <?php endif; ?>
            
            <?php if($subtitle): ?>
            <p class="p-1 text-sm text-gray-500 dark:text-neutral-400">
                <?php echo e($subtitle); ?>

            </p>
            <?php endif; ?>
        </div>
        
        <?php if($headerActions): ?>
        <div class="flex items-center gap-2">
            <?php echo e($headerActions); ?>

        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <div class="<?php echo e($noPadding ? '' : 'p-4'); ?> <?php echo e($bodyClass); ?>">
        <?php echo e($slot); ?>

    </div>
    
    <?php if($footer): ?>
    <div class="px-6 py-4 border-t border-gray-200 dark:border-neutral-700">
        <?php echo e($footer); ?>

    </div>
    <?php endif; ?>
</div><?php /**PATH E:\Toko\project 2025\skripsi s1 informatika\chris\app\company-profile\resources\views/components/admin/card.blade.php ENDPATH**/ ?>